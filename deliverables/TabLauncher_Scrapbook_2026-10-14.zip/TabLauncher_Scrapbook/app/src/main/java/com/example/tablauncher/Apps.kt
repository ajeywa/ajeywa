package com.example.tablauncher

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import android.provider.Settings
import android.widget.Toast

/** One launchable activity of one user profile. [key] is what the layout persists. */
class AppEntry(
    val key: String,
    val label: String,
    val component: ComponentName,
    val user: UserHandle,
    val isPrimaryUser: Boolean,
    /** A pure system app: it can be disabled by the user but not uninstalled. */
    val pureSystem: Boolean,
    val icon: Drawable,
) {
    val packageName: String get() = component.packageName
}

class ShortcutEntry(val info: ShortcutInfo, val label: String, val icon: Drawable?)

/**
 * Everything that touches the system on behalf of an app: listing, launching, app info, uninstall and
 * static/dynamic shortcuts. All of it goes through the platform APIs a launcher is expected to use.
 */
class AppRepository(private val context: Context) {
    private val launcherApps = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
    private val userManager = context.getSystemService(Context.USER_SERVICE) as UserManager

    private fun userKey(user: UserHandle): Long = userManager.getSerialNumberForUser(user)

    fun load(): List<AppEntry> {
        val out = LinkedHashMap<String, AppEntry>()
        val me = Process.myUserHandle()
        for (user in userManager.userProfiles) {
            val list: List<LauncherActivityInfo> = try {
                launcherApps.getActivityList(null, user)
            } catch (_: Exception) {
                emptyList()
            }
            for (info in list) {
                if (info.componentName.packageName == context.packageName) continue
                val flags = info.applicationInfo.flags
                val pureSystem = (flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                val key = keyOf(info.componentName, userKey(user))
                val icon = try {
                    info.getBadgedIcon(0)
                } catch (_: Exception) {
                    continue
                }
                out[key] = AppEntry(
                    key = key,
                    label = info.label?.toString().orEmpty().ifEmpty { info.componentName.packageName },
                    component = info.componentName,
                    user = user,
                    isPrimaryUser = user == me,
                    pureSystem = pureSystem,
                    icon = icon,
                )
            }
        }
        return out.values.sortedBy { it.label.lowercase() }
    }

    /**
     * False only when the app is verifiably gone. Used to prune the layout without being fooled by a
     * temporarily empty query; other profiles are never pruned.
     */
    fun stillInstalled(key: String): Boolean {
        val comp = key.substringBefore('|')
        val serial = key.substringAfter('|', "").toLongOrNull()
        if (serial != userKey(Process.myUserHandle())) return true
        val cn = ComponentName.unflattenFromString(comp) ?: return true
        return try {
            context.packageManager.getActivityInfo(cn, 0)
            true
        } catch (_: android.content.pm.PackageManager.NameNotFoundException) {
            false
        }
    }

    // ---- launching and app management ------------------------------------------------------

    /** Test seam: lets a test observe launches without starting real activities. Never set in production. */
    internal var launchInterceptor: ((AppEntry) -> Boolean)? = null

    fun launch(app: AppEntry, bounds: Rect? = null) {
        if (launchInterceptor?.invoke(app) == true) return
        try {
            launcherApps.startMainActivity(app.component, app.user, bounds, null)
        } catch (e: Exception) {
            Toast.makeText(context, "${app.label} can't be opened right now.", Toast.LENGTH_SHORT).show()
        }
    }

    fun openAppInfo(app: AppEntry, bounds: Rect? = null) {
        try {
            launcherApps.startAppDetailsActivity(app.component, app.user, bounds, null)
        } catch (_: Exception) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", app.packageName, null))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            } catch (_: Exception) {
                Toast.makeText(context, "App info isn't available for ${app.label}.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * True when the system would let the user uninstall (or remove updates of) this app. Pure system apps,
     * this launcher, and profiles with uninstall restrictions are excluded.
     */
    fun canUninstall(app: AppEntry): Boolean {
        if (app.pureSystem || app.packageName == context.packageName) return false
        if (userManager.hasUserRestriction(UserManager.DISALLOW_APPS_CONTROL)) return false
        if (userManager.hasUserRestriction(UserManager.DISALLOW_UNINSTALL_APPS)) return false
        return true
    }

    /** Opens the system uninstall confirmation. Nothing is removed unless the user confirms there. */
    fun uninstall(app: AppEntry) {
        val intent = Intent(Intent.ACTION_DELETE, Uri.fromParts("package", app.packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!app.isPrimaryUser) intent.putExtra(Intent.EXTRA_USER, app.user)
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Uninstalling ${app.label} isn't available here.", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- app shortcuts ----------------------------------------------------------------------

    /**
     * Static and dynamic shortcuts. Android only reveals these to the default home app, so this quietly
     * returns an empty list when Tab Launcher is not (yet) the default.
     */
    fun shortcuts(app: AppEntry, max: Int = 4): List<ShortcutEntry> {
        return try {
            if (!launcherApps.hasShortcutHostPermission()) return emptyList()
            val query = LauncherApps.ShortcutQuery()
                .setPackage(app.packageName)
                .setActivity(app.component)
                .setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST,
                )
            (launcherApps.getShortcuts(query, app.user) ?: emptyList())
                .filter { it.isEnabled }
                .sortedBy { it.rank }
                .take(max)
                .map { info ->
                    ShortcutEntry(
                        info,
                        (info.shortLabel ?: info.longLabel)?.toString().orEmpty(),
                        runCatching { launcherApps.getShortcutIconDrawable(info, 0) }.getOrNull(),
                    )
                }
                .filter { it.label.isNotEmpty() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun startShortcut(entry: ShortcutEntry) {
        try {
            launcherApps.startShortcut(entry.info, null, null)
        } catch (_: Exception) {
            Toast.makeText(context, "That shortcut can't be opened.", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- change notifications ---------------------------------------------------------------

    fun registerCallback(onChange: () -> Unit): LauncherApps.Callback {
        val cb = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String?, user: UserHandle?) = onChange()
            override fun onPackageAdded(packageName: String?, user: UserHandle?) = onChange()
            override fun onPackageChanged(packageName: String?, user: UserHandle?) = onChange()
            override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = onChange()
            override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = onChange()
        }
        launcherApps.registerCallback(cb)
        return cb
    }

    fun unregisterCallback(cb: LauncherApps.Callback) {
        runCatching { launcherApps.unregisterCallback(cb) }
    }

    companion object {
        fun keyOf(component: ComponentName, userSerial: Long) = "${component.flattenToShortString()}|$userSerial"

        fun startHomeSettings(activity: Activity) {
            val intents = listOf(Intent(Settings.ACTION_HOME_SETTINGS), Intent(Settings.ACTION_SETTINGS))
            for (i in intents) {
                try {
                    activity.startActivity(i)
                    return
                } catch (_: Exception) {
                }
            }
        }

        @Suppress("unused")
        val supportsMonochrome: Boolean get() = Build.VERSION.SDK_INT >= 33
    }
}
