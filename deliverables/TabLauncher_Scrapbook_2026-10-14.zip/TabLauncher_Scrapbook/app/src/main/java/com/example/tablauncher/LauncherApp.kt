package com.example.tablauncher

import android.app.Application

class LauncherApp : Application()
