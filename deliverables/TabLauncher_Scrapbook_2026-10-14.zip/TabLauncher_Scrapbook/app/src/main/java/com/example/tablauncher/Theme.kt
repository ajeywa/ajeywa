package com.example.tablauncher

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * A palette drives the generated backdrop, glyph colour and the cream "paper" tiles.
 * c0..c2 run diagonally across the backdrop, [glow] blooms from the lower right corner.
 */
data class Palette(
    val name: String,
    val c0: Color,
    val c1: Color,
    val c2: Color,
    val glow: Color,
    val bloom: Color,
    val glyph: Color,
    val paper: Color,
    val paperInk: Color,
)

val Palettes = listOf(
    // Blue-grey fading into dusty lavender with a warm cream glow (reference 1).
    Palette(
        "Dusk", Color(0xFF5B6F8C), Color(0xFF8D93B4), Color(0xFFC3BDD0), Color(0xFFF0E1C2), Color(0xFFB9C4B4),
        Color(0xFFFBF8F2), Color(0xFFE9E0CC), Color(0xFF5A6D91),
    ),
    // Sage and moss (reference 2).
    Palette(
        "Sage", Color(0xFF3E5046), Color(0xFF6B8270), Color(0xFFA7B8A2), Color(0xFFDCE2C6), Color(0xFF8A94B2),
        Color(0xFFF4F6EE), Color(0xFFE6E8D6), Color(0xFF4C6354),
    ),
    // Dusty lavender with a rosy glow.
    Palette(
        "Lavender", Color(0xFF6C688F), Color(0xFF9A92B8), Color(0xFFC9C1DA), Color(0xFFEBD9D6), Color(0xFFA9BCB1),
        Color(0xFFFFFFFF), Color(0xFFEEE4DA), Color(0xFF6E6794),
    ),
    // Deep navy with silver glass (reference 3).
    Palette(
        "Midnight", Color(0xFF1C2842), Color(0xFF2E4062), Color(0xFF55688C), Color(0xFF8A9AB5), Color(0xFF6F7FA6),
        Color(0xFFE9EEF7), Color(0xFFD9DEE8), Color(0xFF2E4062),
    ),
)

val LocalPalette = compositionLocalOf { Palettes[0] }

@Composable
fun LauncherTheme(palette: Palette, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = palette.paperInk,
            secondary = palette.c1,
            background = palette.c0,
            surface = palette.paper,
        ),
    ) {
        CompositionLocalProvider(LocalPalette provides palette, content = content)
    }
}
