package com.example.tablauncher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.util.UUID

/**
 * The default scrapbook composition. Pure functions so it can be unit-tested.
 * Coordinates are cells in the fixed grids of [GridSpec].
 */
object DefaultLayout {
    private fun id() = UUID.randomUUID().toString()

    private val landAppSlots = listOf(3 to 4, 4 to 5, 6 to 4, 7 to 5, 9 to 4, 10 to 5, 11 to 4)
    private val portAppSlots = listOf(0 to 8, 1 to 9, 2 to 8, 3 to 9, 4 to 8)

    fun build(
        homeAppKeys: List<String>,
        dockKeys: List<String>,
        widgetItems: List<HomeItem>,
        settings: LauncherSettings = LauncherSettings(),
        quote: String = "take it slow.",
    ): LauncherState {
        var items = emptyList<HomeItem>()

        fun add(item: HomeItem) { items = items + item }

        // Decor first: a tall arch of paper-cut art, a bare clock, a cream note and a tilted polaroid.
        add(HomeItem(id(), ItemKind.PHOTO, style = 1, land = Cell(0, 0, 3, 4), port = Cell(0, 0, 3, 4)))
        add(HomeItem(id(), ItemKind.CLOCK, land = Cell(3, 0, 5, 2), port = Cell(3, 0, 4, 2)))
        add(HomeItem(id(), ItemKind.QUOTE, text = quote, land = Cell(9, 0, 3, 2), port = Cell(3, 2, 4, 2)))
        add(HomeItem(id(), ItemKind.PHOTO, style = 2, tilt = -3f, land = Cell(0, 4, 2, 2), port = Cell(5, 8, 2, 2)))

        // Existing widgets keep their ids; only their positions are new.
        val landWidgetRegion = Cell(3, 2, 9, 2)
        val portWidgetRegion = Cell(0, 4, 7, 4)
        for (w in widgetItems) {
            val (lw, lh) = w.land?.let { it.w to it.h } ?: (3 to 2)
            val (pw, ph) = w.port?.let { it.w to it.h } ?: (lw.coerceAtMost(GridSpec.PORT_COLS) to lh)
            val land = LayoutEngine.autoPlace(lw, lh, items, Orient.LAND, landWidgetRegion)
                ?: LayoutEngine.autoPlace(lw, lh, items, Orient.LAND)
            val port = LayoutEngine.autoPlace(pw, ph, items, Orient.PORT, portWidgetRegion)
                ?: LayoutEngine.autoPlace(pw, ph, items, Orient.PORT)
            add(w.copy(land = land, port = port))
        }

        // Apps are scattered on staggered slots instead of a rigid grid.
        homeAppKeys.forEachIndexed { index, key ->
            var land = landAppSlots.getOrNull(index)?.let { Cell(it.first, it.second, 1, 1) }
            if (land == null || !LayoutEngine.isFree(land, items, Orient.LAND)) {
                land = LayoutEngine.autoPlace(1, 1, items, Orient.LAND, Cell(3, 4, 9, 2))
                    ?: LayoutEngine.autoPlace(1, 1, items, Orient.LAND)
            }
            var port = portAppSlots.getOrNull(index)?.let { Cell(it.first, it.second, 1, 1) }
            if (port == null || !LayoutEngine.isFree(port, items, Orient.PORT)) {
                port = LayoutEngine.autoPlace(1, 1, items, Orient.PORT, Cell(0, 8, 5, 2))
                    ?: LayoutEngine.autoPlace(1, 1, items, Orient.PORT)
            }
            add(HomeItem(id(), ItemKind.APP, appKey = key, land = land, port = port))
        }
        return LauncherState(items, dockKeys.distinct().take(LauncherStore.DOCK_MAX), settings)
    }
}

/**
 * Persists the home layout and settings as JSON in the same "launcher" preferences file the previous
 * version used, so an update in place keeps working. The old keys (`widget_ids`, `favorites`,
 * `favorites_customized`) are read once for migration and `widget_ids` is kept in sync afterwards.
 */
class LauncherStore(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var state by mutableStateOf(readState())
        private set

    /** False until the first apps list has arrived and a brand-new / migrated layout has been seeded. */
    private var seeded: Boolean = prefs.contains(KEY_LAYOUT)

    private fun readState(): LauncherState {
        val raw = prefs.getString(KEY_LAYOUT, null) ?: return LauncherState()
        return runCatching { LauncherState.fromJson(JSONObject(raw)) }.getOrDefault(LauncherState())
    }

    private fun persist() {
        seeded = true
        prefs.edit()
            .putString(KEY_LAYOUT, state.toJson().toString())
            // Keep the legacy key valid so downgrading to the previous build still finds its widgets.
            .putStringSet(KEY_LEGACY_WIDGETS, state.items.filter { it.kind == ItemKind.WIDGET }.map { it.widgetId.toString() }.toSet())
            .apply()
    }

    private inline fun mutate(block: (LauncherState) -> LauncherState) {
        state = block(state)
        persist()
    }

    // ---- first start / migration ------------------------------------------------------------

    fun legacyWidgetIds(): List<Int> =
        prefs.getStringSet(KEY_LEGACY_WIDGETS, emptySet()).orEmpty().mapNotNull { it.toIntOrNull() }.sorted()

    fun legacyFavoritePackages(): List<String>? =
        if (prefs.getBoolean("favorites_customized", false)) prefs.getStringSet("favorites", emptySet()).orEmpty().toList() else null

    /**
     * Called each time the app list is (re)loaded. On the very first run it builds the default layout
     * from the user's real apps and carries over any widgets and favourites from the previous version.
     */
    fun onAppsLoaded(apps: List<AppEntry>, widgetSizeFor: (Int) -> Pair<Int, Int>?) {
        if (seeded || apps.isEmpty()) return
        val byPackage = apps.filter { it.isPrimaryUser }.associateBy { it.packageName }
        fun keyFor(pkg: String) = byPackage[pkg]?.key

        val legacyFav = legacyFavoritePackages()?.mapNotNull(::keyFor).orEmpty()
        val resolved = defaultAppKeys(apps)

        val dock = (legacyFav.take(4) + resolved.dock).distinct().take(5)
        var home = (legacyFav.drop(4) + resolved.home).distinct().filter { it !in dock }.take(7)
        // A device that doesn't expose the usual apps by intent still gets a populated, usable Home.
        if (home.size < 5) {
            home = (home + apps.map { it.key }.filter { it !in dock && it !in home }.take(5 - home.size))
        }

        val widgets = legacyWidgetIds().map { id ->
            val span = widgetSizeFor(id)
            HomeItem(
                id = UUID.randomUUID().toString(), kind = ItemKind.WIDGET, widgetId = id,
                land = span?.let { Cell(0, 0, it.first, it.second) },
                port = span?.let { Cell(0, 0, it.first.coerceAtMost(GridSpec.PORT_COLS), it.second) },
            )
        }
        state = DefaultLayout.build(home, dock, widgets)
        persist()
    }

    private class Defaults(val dock: List<String>, val home: List<String>)

    /** Picks sensible starter apps by asking the system who handles the common intents. */
    private fun defaultAppKeys(apps: List<AppEntry>): Defaults {
        val pm = context.packageManager
        val byPackage = apps.filter { it.isPrimaryUser }.associateBy { it.packageName }
        fun resolve(intent: Intent): String? {
            val pkg = runCatching { pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }.getOrNull()
            return pkg?.let { byPackage[it]?.key }
        }
        fun category(c: String) = Intent(Intent.ACTION_MAIN).addCategory(c)

        val dock = listOfNotNull(
            resolve(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://example.com"))),
            resolve(category(Intent.CATEGORY_APP_GALLERY)),
            resolve(Intent(MediaStore.ACTION_IMAGE_CAPTURE)),
            resolve(category(Intent.CATEGORY_APP_MESSAGING)),
            resolve(Intent(Settings.ACTION_SETTINGS)),
        )
        val home = listOfNotNull(
            resolve(category(Intent.CATEGORY_APP_CALENDAR)),
            resolve(category(Intent.CATEGORY_APP_MUSIC)),
            resolve(category(Intent.CATEGORY_APP_MAPS)),
            resolve(category(Intent.CATEGORY_APP_EMAIL)),
            resolve(category(Intent.CATEGORY_APP_CONTACTS)),
            resolve(Intent(Intent.ACTION_DIAL)),
        )
        val fallbackDock = dock.ifEmpty { apps.take(4).map { it.key } }
        return Defaults(fallbackDock, home)
    }

    /** Re-creates the default composition. Widgets and apps are kept; only positions and decor reset. */
    fun resetLayout(apps: List<AppEntry>) {
        val resolved = defaultAppKeys(apps)
        val widgets = state.items.filter { it.kind == ItemKind.WIDGET }.map { it.copy(land = it.land?.copy(col = 0, row = 0), port = it.port?.copy(col = 0, row = 0)) }
        val dock = state.dock.ifEmpty { resolved.dock }
        val home = (state.items.filter { it.kind == ItemKind.APP }.mapNotNull { it.appKey } + resolved.home)
            .distinct().filter { it !in dock }.take(7)
        mutate { DefaultLayout.build(home, dock, widgets, it.settings) }
    }

    // ---- housekeeping -----------------------------------------------------------------------

    /** Gives items without a position in this orientation one, without moving anything that has one. */
    fun ensureCells(o: Orient) {
        val fixed = LayoutEngine.ensureCells(state.items, o)
        if (fixed != state.items) mutate { it.copy(items = fixed) }
    }

    /** Drops placements of apps that are really gone (uninstalled), not merely missing from a failed query. */
    fun pruneUninstalled(isStillInstalled: (String) -> Boolean) {
        val gone = state.items.filter { it.kind == ItemKind.APP && it.appKey != null && !isStillInstalled(it.appKey) }
        val goneDock = state.dock.filter { !isStillInstalled(it) }
        if (gone.isEmpty() && goneDock.isEmpty()) return
        mutate { s -> s.copy(items = s.items.filter { it !in gone }, dock = s.dock.filter { it !in goneDock }) }
    }

    // ---- mutations --------------------------------------------------------------------------

    fun item(id: String): HomeItem? = state.items.firstOrNull { it.id == id }

    fun isOnHome(appKey: String) = state.items.any { it.kind == ItemKind.APP && it.appKey == appKey }
    fun isInDock(appKey: String) = appKey in state.dock

    /** Adds an app icon where there is room. Returns false when the app is already there or no room is left. */
    fun addApp(appKey: String, o: Orient): Boolean {
        if (isOnHome(appKey)) return false
        val cell = LayoutEngine.autoPlace(1, 1, state.items, o) ?: return false
        mutate { it.copy(items = it.items + HomeItem(UUID.randomUUID().toString(), ItemKind.APP, appKey = appKey).withCell(o, cell)) }
        return true
    }

    /** Adds a decor item (photo, note, clock) of the given footprint. Returns the new item or null if full. */
    fun addDecor(template: HomeItem, o: Orient, w: Int, h: Int): HomeItem? {
        val cell = LayoutEngine.autoPlace(w, h, state.items, o)
            ?: LayoutEngine.autoPlace(minOf(w, 2), minOf(h, 2), state.items, o)
            ?: return null
        val item = template.withCell(o, cell)
        mutate { it.copy(items = it.items + item) }
        return item
    }

    /** Called once a widget id has been bound and (if needed) configured. */
    fun addWidget(widgetId: Int, spanLand: Pair<Int, Int>, spanPort: Pair<Int, Int>): Boolean {
        val items = state.items
        val land = LayoutEngine.autoPlace(spanLand.first, spanLand.second, items, Orient.LAND)
        val port = LayoutEngine.autoPlace(spanPort.first, spanPort.second, items, Orient.PORT)
        if (land == null && port == null) return false
        val item = HomeItem(UUID.randomUUID().toString(), ItemKind.WIDGET, widgetId = widgetId, land = land, port = port)
        mutate { it.copy(items = it.items + item) }
        return true
    }

    fun removeItem(id: String) = mutate { it.copy(items = it.items.filter { i -> i.id != id }) }

    fun updateItem(id: String, change: (HomeItem) -> HomeItem) =
        mutate { s -> s.copy(items = s.items.map { if (it.id == id) change(it) else it }) }

    /** Moves an item and brings it to the front of the z-order. */
    fun moveItem(id: String, o: Orient, cell: Cell) = mutate { s ->
        val moved = s.items.firstOrNull { it.id == id }?.withCell(o, cell) ?: return@mutate s
        s.copy(items = s.items.filter { it.id != id } + moved)
    }

    fun resizeItem(id: String, o: Orient, cell: Cell) = updateItem(id) { it.withCell(o, cell) }

    fun addToDock(key: String): Boolean {
        if (key in state.dock || state.dock.size >= DOCK_MAX) return false
        mutate { it.copy(dock = it.dock + key) }
        return true
    }

    fun removeFromDock(key: String) = mutate { it.copy(dock = it.dock - key) }

    fun moveDock(from: Int, to: Int) = mutate { s ->
        if (from !in s.dock.indices) return@mutate s
        val list = s.dock.toMutableList()
        val k = list.removeAt(from)
        list.add(to.coerceIn(0, list.size), k)
        s.copy(dock = list)
    }

    fun updateSettings(change: (LauncherSettings) -> LauncherSettings) = mutate { it.copy(settings = change(it.settings)) }

    companion object {
        const val PREFS = "launcher"
        const val KEY_LAYOUT = "layout_v2"
        const val KEY_LEGACY_WIDGETS = "widget_ids"
        const val DOCK_MAX = 7
    }
}
