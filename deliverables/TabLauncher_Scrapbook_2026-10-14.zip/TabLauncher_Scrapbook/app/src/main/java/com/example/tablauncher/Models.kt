package com.example.tablauncher

import org.json.JSONArray
import org.json.JSONObject

/** Everything that can sit on the Home canvas. */
enum class ItemKind { APP, WIDGET, PHOTO, QUOTE, CLOCK }

enum class Orient { LAND, PORT }

enum class WallpaperMode { SYSTEM, BACKDROP, PHOTO }

enum class IconStyle { GLYPH, ORIGINAL }

/**
 * Home uses a fixed logical grid per orientation. Cell size is derived from the space that is left
 * after insets and the dock, so a layout looks the same on any tablet and each orientation keeps its
 * own arrangement.
 */
object GridSpec {
    const val LAND_COLS = 12
    const val LAND_ROWS = 6
    const val PORT_COLS = 7
    const val PORT_ROWS = 10

    /** Used only to translate a widget provider's requested size into a default number of cells. */
    const val REFERENCE_CELL_DP = 86f

    fun cols(o: Orient) = if (o == Orient.LAND) LAND_COLS else PORT_COLS
    fun rows(o: Orient) = if (o == Orient.LAND) LAND_ROWS else PORT_ROWS
}

data class Cell(val col: Int, val row: Int, val w: Int, val h: Int) {
    fun overlaps(o: Cell) =
        col < o.col + o.w && o.col < col + w && row < o.row + o.h && o.row < row + h

    fun fits(cols: Int, rows: Int) =
        col >= 0 && row >= 0 && w >= 1 && h >= 1 && col + w <= cols && row + h <= rows

    fun clampedTo(cols: Int, rows: Int): Cell {
        val cw = w.coerceIn(1, cols)
        val ch = h.coerceIn(1, rows)
        return Cell(col.coerceIn(0, cols - cw), row.coerceIn(0, rows - ch), cw, ch)
    }

    fun toJson(): JSONArray = JSONArray().put(col).put(row).put(w).put(h)

    companion object {
        fun fromJson(a: JSONArray?): Cell? =
            if (a == null || a.length() < 4) null else Cell(a.getInt(0), a.getInt(1), a.getInt(2), a.getInt(3))
    }
}

data class HomeItem(
    val id: String,
    val kind: ItemKind,
    /** APP: stable app key (see [AppEntry.key]). */
    val appKey: String? = null,
    /** WIDGET: the AppWidgetHost id. */
    val widgetId: Int = -1,
    /** QUOTE: the text. */
    val text: String = "",
    /** PHOTO: file name inside filesDir/photos, or null for the built-in paper-cut artwork. */
    val photo: String? = null,
    /** PHOTO: 0 rounded, 1 arch, 2 polaroid. QUOTE: 0 cream card, 1 bare text. */
    val style: Int = 0,
    /** Small decorative rotation in degrees (scrapbook feel). Purely visual. */
    val tilt: Float = 0f,
    val land: Cell? = null,
    val port: Cell? = null,
) {
    fun cellFor(o: Orient): Cell? = if (o == Orient.LAND) land else port
    fun withCell(o: Orient, c: Cell?): HomeItem = if (o == Orient.LAND) copy(land = c) else copy(port = c)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("kind", kind.name)
        appKey?.let { put("appKey", it) }
        if (widgetId != -1) put("widgetId", widgetId)
        if (text.isNotEmpty()) put("text", text)
        photo?.let { put("photo", it) }
        if (style != 0) put("style", style)
        if (tilt != 0f) put("tilt", tilt.toDouble())
        land?.let { put("land", it.toJson()) }
        port?.let { put("port", it.toJson()) }
    }

    companion object {
        fun fromJson(o: JSONObject): HomeItem? {
            val kind = runCatching { ItemKind.valueOf(o.getString("kind")) }.getOrNull() ?: return null
            return HomeItem(
                id = o.optString("id").ifEmpty { return null },
                kind = kind,
                appKey = o.optString("appKey").ifEmpty { null },
                widgetId = o.optInt("widgetId", -1),
                text = o.optString("text", ""),
                photo = o.optString("photo").ifEmpty { null },
                style = o.optInt("style", 0),
                tilt = o.optDouble("tilt", 0.0).toFloat(),
                land = Cell.fromJson(o.optJSONArray("land")),
                port = Cell.fromJson(o.optJSONArray("port")),
            )
        }
    }
}

data class LauncherSettings(
    val palette: Int = 0,
    val wallpaper: WallpaperMode = WallpaperMode.BACKDROP,
    val wallpaperPhoto: String? = null,
    val iconStyle: IconStyle = IconStyle.GLYPH,
    val showLabels: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("palette", palette)
        put("wallpaper", wallpaper.name)
        wallpaperPhoto?.let { put("wallpaperPhoto", it) }
        put("iconStyle", iconStyle.name)
        put("showLabels", showLabels)
    }

    companion object {
        fun fromJson(o: JSONObject?): LauncherSettings {
            if (o == null) return LauncherSettings()
            return LauncherSettings(
                palette = o.optInt("palette", 0),
                wallpaper = runCatching { WallpaperMode.valueOf(o.optString("wallpaper")) }.getOrDefault(WallpaperMode.BACKDROP),
                wallpaperPhoto = o.optString("wallpaperPhoto").ifEmpty { null },
                iconStyle = runCatching { IconStyle.valueOf(o.optString("iconStyle")) }.getOrDefault(IconStyle.GLYPH),
                showLabels = o.optBoolean("showLabels", true),
            )
        }
    }
}

data class LauncherState(
    val items: List<HomeItem> = emptyList(),
    /** Ordered app keys shown in the floating dock. */
    val dock: List<String> = emptyList(),
    val settings: LauncherSettings = LauncherSettings(),
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("version", 2)
        put("items", JSONArray().also { a -> items.forEach { a.put(it.toJson()) } })
        put("dock", JSONArray().also { a -> dock.forEach { a.put(it) } })
        put("settings", settings.toJson())
    }

    companion object {
        fun fromJson(o: JSONObject): LauncherState {
            val items = mutableListOf<HomeItem>()
            val arr = o.optJSONArray("items")
            if (arr != null) for (i in 0 until arr.length()) {
                arr.optJSONObject(i)?.let { HomeItem.fromJson(it) }?.let(items::add)
            }
            val dock = mutableListOf<String>()
            val d = o.optJSONArray("dock")
            if (d != null) for (i in 0 until d.length()) d.optString(i).takeIf { it.isNotEmpty() }?.let(dock::add)
            return LauncherState(items, dock, LauncherSettings.fromJson(o.optJSONObject("settings")))
        }
    }
}
