package com.example.tablauncher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.union
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

/**
 * Layer order, bottom to top:
 *   wallpaper -> home (canvas, dock, edit bar) -> app drawer -> long-press menu -> sheets.
 * The drawer slides over Home; Home recedes slightly as it opens.
 */
@Composable
fun LauncherRoot(env: LauncherEnv, apps: List<AppEntry>) {
    val ui = env.ui
    val state = env.store.state
    val palette = Palettes[state.settings.palette.coerceIn(Palettes.indices)]
    val byKey = remember(apps) { apps.associateBy { it.key } }
    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    val bottomInsets = WindowInsets.systemBars.union(WindowInsets.displayCutout)

    // Clears "pick an app" mode whenever the drawer is gone.
    LaunchedEffect(ui.drawer.isVisible) { if (!ui.drawer.isVisible) ui.pickApp = false }

    // The last handler wins, so register the broadest one first. Home does nothing on Back, as on any launcher.
    BackHandler(enabled = true) {}
    BackHandler(enabled = ui.anyOverlay) {
        when {
            ui.menu != null -> ui.menu = null
            ui.sheet != SheetKind.NONE -> ui.closeSheet()
            ui.drawer.isVisible -> ui.drawer.close()
            ui.editing -> ui.editing = false
        }
    }

    val backdrop: (@Composable () -> Unit)? =
        if (state.settings.wallpaper == WallpaperMode.SYSTEM) null else ({ WallpaperSurface(state.settings, palette) })

    val context = LocalContext.current
    val reduceMotion = remember {
        runCatching {
            android.provider.Settings.Global.getFloat(context.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        }.getOrDefault(false)
    }

    LauncherTheme(palette) {
        CompositionLocalProvider(LocalBackdrop provides backdrop, LocalRootSize provides rootSize, LocalReduceMotion provides reduceMotion) {
            Box(Modifier.fillMaxSize().onSizeChanged { rootSize = it }) {
                WallpaperSurface(state.settings, palette)

                val p = ui.drawer.progress
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        val s = 1f - 0.05f * p
                        scaleX = s
                        scaleY = s
                        alpha = 1f - 0.8f * p
                    },
                ) {
                    HomeCanvas(env, byKey)

                    // The dock band doubles as a swipe-up start zone. It must stay inside DockZone, the space the
                    // home grid reserves at the bottom, or it would swallow touches meant for the bottom icon row.
                    Box(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .swipeUpToOpenDrawer(ui.drawer, enabled = !ui.editing)
                            .windowInsetsPadding(bottomInsets)
                            .padding(bottom = 14.dp),
                        contentAlignment = Alignment.BottomCenter,
                    ) { DockBar(env, byKey) }

                    if (ui.editing) {
                        EditBar(
                            env,
                            Modifier.align(Alignment.TopCenter).windowInsetsPadding(bottomInsets).padding(top = 8.dp, start = 16.dp, end = 16.dp),
                        )
                    }
                }

                if (ui.drawer.isVisible) AppDrawer(env, apps)
                ContextMenuLayer(env, byKey)
                SheetLayer(env)
            }
        }
    }
}
