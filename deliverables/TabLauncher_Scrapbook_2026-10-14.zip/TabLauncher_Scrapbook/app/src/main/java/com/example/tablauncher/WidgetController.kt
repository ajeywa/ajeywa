package com.example.tablauncher

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import kotlin.math.ceil

/** One entry in the widget picker. */
class WidgetChoice(
    val info: AppWidgetProviderInfo,
    val label: String,
    val appLabel: String,
    val preview: Drawable?,
    val spanW: Int,
    val spanH: Int,
)

/**
 * Owns the real Android [AppWidgetHost]. Host id 2048 is the id the previous version used, so widgets that
 * were already bound keep working after an in-place update.
 *
 * Adding a widget follows the platform flow: allocate id, bind (asking the user for consent via the
 * system dialog when Android requires it), run the widget's configuration activity if it has one, and
 * only then place it. An id that never makes it that far is deleted again.
 */
class WidgetController(
    private val activity: ComponentActivity,
    private val store: LauncherStore,
) {
    val host = AppWidgetHost(activity, HOST_ID)
    val manager: AppWidgetManager = AppWidgetManager.getInstance(activity)
    private val prefs = activity.getSharedPreferences(LauncherStore.PREFS, Context.MODE_PRIVATE)

    private var pendingId: Int
        get() = prefs.getInt(KEY_PENDING, -1)
        set(v) { prefs.edit().putInt(KEY_PENDING, v).apply() }

    private val bindLauncher = activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = pendingId
        if (id == -1) return@registerForActivityResult
        if (result.resultCode == Activity.RESULT_OK) afterBound(id) else abandon(id, "Widget wasn't allowed")
    }

    /** Forwarded from Activity.onActivityResult for the configure activity request. */
    fun onConfigureResult(resultCode: Int, data: Intent?) {
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)?.takeIf { it != -1 } ?: pendingId
        if (id == -1) return
        if (resultCode == Activity.RESULT_OK) finish(id) else abandon(id, null)
    }

    /** Cleans up an id that was allocated but never completed, e.g. the process died in a dialog. */
    fun cleanUpInterruptedAdd() {
        val id = pendingId
        if (id == -1) return
        if (store.state.items.none { it.kind == ItemKind.WIDGET && it.widgetId == id }) {
            runCatching { host.deleteAppWidgetId(id) }
        }
        pendingId = -1
    }

    fun start() { runCatching { host.startListening() } }
    fun stop() { runCatching { host.stopListening() } }

    // ---- picker data ------------------------------------------------------------------------

    fun loadChoices(): List<WidgetChoice> {
        val pm = activity.packageManager
        val density = activity.resources.displayMetrics.density
        return runCatching { manager.installedProviders }.getOrDefault(emptyList())
            .mapNotNull { info ->
                runCatching {
                    val (w, h) = spanFor(info, density)
                    WidgetChoice(
                        info = info,
                        label = info.loadLabel(pm)?.toString().orEmpty(),
                        appLabel = pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString(),
                        preview = runCatching { info.loadPreviewImage(activity, 0) }.getOrNull()
                            ?: runCatching { info.loadIcon(activity, 0) }.getOrNull(),
                        spanW = w,
                        spanH = h,
                    )
                }.getOrNull()
            }
            .sortedWith(compareBy({ it.appLabel.lowercase() }, { it.label.lowercase() }))
    }

    /** Footprint in grid cells. Provider sizes are reported in pixels. */
    fun spanFor(info: AppWidgetProviderInfo, density: Float = activity.resources.displayMetrics.density): Pair<Int, Int> {
        fun cells(px: Int, max: Int) = ceil((px / density) / GridSpec.REFERENCE_CELL_DP).toInt().coerceIn(1, max)
        return cells(info.minWidth, GridSpec.LAND_COLS) to cells(info.minHeight, GridSpec.LAND_ROWS)
    }

    fun spanForId(id: Int): Pair<Int, Int>? = manager.getAppWidgetInfo(id)?.let { spanFor(it) }

    /** Smallest span the widget allows when resized (defaults to 1x1 when it doesn't say). */
    fun minSpan(id: Int): Pair<Int, Int> {
        val info = manager.getAppWidgetInfo(id) ?: return 1 to 1
        val d = activity.resources.displayMetrics.density
        fun cells(px: Int) = if (px <= 0) 1 else ceil((px / d) / GridSpec.REFERENCE_CELL_DP).toInt().coerceAtLeast(1)
        return cells(info.minResizeWidth) to cells(info.minResizeHeight)
    }

    fun resizeMode(id: Int): Int = manager.getAppWidgetInfo(id)?.resizeMode ?: AppWidgetProviderInfo.RESIZE_NONE

    // ---- add / remove -----------------------------------------------------------------------

    fun add(choice: WidgetChoice) {
        val id = try {
            host.allocateAppWidgetId()
        } catch (e: Exception) {
            Toast.makeText(activity, "Couldn't create a widget slot.", Toast.LENGTH_SHORT).show()
            return
        }
        pendingId = id
        val allowed = try {
            if (choice.info.profile == null || choice.info.profile == android.os.Process.myUserHandle()) {
                manager.bindAppWidgetIdIfAllowed(id, choice.info.provider)
            } else {
                // Widgets that live in a work profile need the profile-aware overload.
                manager.bindAppWidgetIdIfAllowed(id, choice.info.profile, choice.info.provider, null)
            }
        } catch (e: Exception) {
            false
        }
        if (allowed) {
            afterBound(id)
        } else {
            // Android requires the user to approve binding widgets from this app.
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, choice.info.provider)
                choice.info.profile?.let { putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER_PROFILE, it) }
            }
            try {
                bindLauncher.launch(intent)
            } catch (_: ActivityNotFoundException) {
                abandon(id, "This device can't approve widgets for Tab Launcher")
            }
        }
    }

    private fun afterBound(id: Int) {
        val info = manager.getAppWidgetInfo(id)
        if (info?.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(activity, id, 0, REQUEST_CONFIGURE, null)
            } catch (e: Exception) {
                abandon(id, "This widget's setup screen couldn't be opened")
            }
        } else {
            finish(id)
        }
    }

    private fun finish(id: Int) {
        val info = manager.getAppWidgetInfo(id)
        if (info == null) { abandon(id, "That widget isn't available"); return }
        val land = spanFor(info)
        val port = land.first.coerceAtMost(GridSpec.PORT_COLS) to land.second.coerceAtMost(GridSpec.PORT_ROWS)
        pendingId = -1
        if (!store.addWidget(id, land, port)) {
            runCatching { host.deleteAppWidgetId(id) }
            Toast.makeText(activity, "There's no room on Home for that widget.", Toast.LENGTH_LONG).show()
        }
    }

    private fun abandon(id: Int, message: String?) {
        runCatching { host.deleteAppWidgetId(id) }
        pendingId = -1
        if (message != null) Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
    }

    /** Removes the widget from Home and releases its id so the provider stops updating it. */
    fun remove(item: HomeItem) {
        if (item.widgetId != -1) runCatching { host.deleteAppWidgetId(item.widgetId) }
        store.removeItem(item.id)
    }

    // ---- views ------------------------------------------------------------------------------

    fun createView(id: Int): AppWidgetHostView? {
        val info = manager.getAppWidgetInfo(id) ?: return null
        return runCatching { host.createView(activity, id, info) }.getOrNull()
    }

    /** Tells the widget how much room it has so it can pick the right layout. Sizes are in dp. */
    fun notifySize(view: AppWidgetHostView, widthDp: Int, heightDp: Int) {
        runCatching {
            view.updateAppWidgetSize(Bundle.EMPTY, widthDp, heightDp, widthDp, heightDp)
        }
    }

    companion object {
        const val HOST_ID = 2048
        const val REQUEST_CONFIGURE = 9002
        private const val KEY_PENDING = "pending_widget_id"
    }
}
