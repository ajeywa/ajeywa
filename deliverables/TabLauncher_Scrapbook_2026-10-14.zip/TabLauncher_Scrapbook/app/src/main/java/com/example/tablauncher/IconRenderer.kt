package com.example.tablauncher

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Turns an app's launcher icon into a bitmap in one of two looks:
 *
 *  - GLYPH: the icon's silhouette (the system "themed" monochrome layer on Android 13+, otherwise the
 *    adaptive foreground layer) filled with a single palette colour and a soft shadow. No container.
 *  - ORIGINAL: the app's own full-colour icon, with the same soft shadow.
 *
 * A silhouette is only used when it really is a silhouette. Icons whose artwork fills its whole canvas
 * would turn into a solid block, so those fall back to a gently desaturated original instead.
 */
object IconRenderer {
    const val SIZE = 160
    private const val PAD = 16
    const val TOTAL = SIZE + PAD * 2
    private const val GLYPH_SCALE = 0.92f

    fun render(source: Drawable, style: IconStyle, tint: Int): Bitmap {
        val drawable = source.constantState?.newDrawable()?.mutate() ?: source
        val art = when (style) {
            IconStyle.ORIGINAL -> drawOriginal(drawable, 1f)
            IconStyle.GLYPH -> glyphMask(drawable)?.let { tinted(it, tint) } ?: drawOriginal(drawable, 0.35f)
        }
        return withShadow(art)
    }

    private fun newLayer(): Pair<Bitmap, Canvas> {
        val b = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        return b to Canvas(b)
    }

    private fun drawOriginal(d: Drawable, saturation: Float): Bitmap {
        val (bmp, canvas) = newLayer()
        d.setBounds(0, 0, SIZE, SIZE)
        d.draw(canvas)
        if (saturation >= 1f) return bmp
        val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(saturation) })
            alpha = 235
        }
        Canvas(out).drawBitmap(bmp, 0f, 0f, paint)
        return out
    }

    /** Alpha-only silhouette of the glyph, or null when the icon has no usable silhouette. */
    private fun glyphMask(d: Drawable): Bitmap? {
        val (bmp, canvas) = newLayer()
        if (d is AdaptiveIconDrawable) {
            val layer: Drawable = (if (Build.VERSION.SDK_INT >= 33) d.monochrome else null) ?: d.foreground ?: return null
            // Adaptive layers are drawn on a 108dp canvas of which only the centre 72dp is visible.
            val inset = (SIZE * 0.25f).toInt()
            layer.setBounds(-inset, -inset, SIZE + inset, SIZE + inset)
            layer.draw(canvas)
        } else {
            d.setBounds(0, 0, SIZE, SIZE)
            d.draw(canvas)
        }
        return if (looksLikeSilhouette(bmp)) bmp else null
    }

    private fun looksLikeSilhouette(b: Bitmap): Boolean {
        val lo = (SIZE * 0.14f).toInt()
        val hi = SIZE - lo
        var solid = 0
        var total = 0
        var any = 0
        val step = 4
        var y = lo
        while (y < hi) {
            var x = lo
            while (x < hi) {
                val a = (b.getPixel(x, y) ushr 24)
                if (a > 128) solid++
                if (a > 16) any++
                total++
                x += step
            }
            y += step
        }
        if (total == 0 || any == 0) return false
        return solid.toFloat() / total < 0.80f
    }

    private fun tinted(mask: Bitmap, tint: Int): Bitmap {
        val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = PorterDuffColorFilter(tint, PorterDuff.Mode.SRC_IN)
        }
        val canvas = Canvas(out)
        canvas.save()
        canvas.scale(GLYPH_SCALE, GLYPH_SCALE, SIZE / 2f, SIZE / 2f)
        canvas.drawBitmap(mask, 0f, 0f, paint)
        canvas.restore()
        return out
    }

    private fun withShadow(art: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(TOTAL, TOTAL, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val blur = Paint().apply { maskFilter = BlurMaskFilter(7f, BlurMaskFilter.Blur.NORMAL) }
        val offset = IntArray(2)
        val shadow = art.extractAlpha(blur, offset)
        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.argb(78, 14, 20, 38) }
        canvas.drawBitmap(shadow, (PAD + offset[0]).toFloat(), (PAD + offset[1] + 4).toFloat(), shadowPaint)
        canvas.drawBitmap(art, PAD.toFloat(), PAD.toFloat(), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return out
    }
}

/** Renders off the main thread and remembers the result. */
class IconCache {
    private val cache = LruCache<String, ImageBitmap>(480)

    fun peek(key: String): ImageBitmap? = cache.get(key)

    suspend fun get(key: String, drawable: Drawable, style: IconStyle, tint: Int): ImageBitmap {
        cache.get(key)?.let { return it }
        val bmp = withContext(Dispatchers.Default) { IconRenderer.render(drawable, style, tint).asImageBitmap() }
        cache.put(key, bmp)
        return bmp
    }
}

val LocalIconCache = compositionLocalOf { IconCache() }

@Composable
fun AppGlyph(app: AppEntry, style: IconStyle, tint: Color, size: Dp, modifier: Modifier = Modifier) {
    val cache = LocalIconCache.current
    val tintInt = tint.toArgb()
    val key = "${app.key}|${style.name}|$tintInt"
    val bmp by produceState(cache.peek(key), key) { value = cache.get(key, app.icon, style, tintInt) }
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        bmp?.let {
            Image(
                bitmap = it,
                contentDescription = null,
                modifier = Modifier.requiredSize(size * (IconRenderer.TOTAL.toFloat() / IconRenderer.SIZE)),
            )
        }
    }
}
