package com.example.tablauncher

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.text.format.DateFormat
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.OpenInFull
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.compose.foundation.Image
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt

/** Everything the composables need from the outside world. */
class LauncherEnv(
    val activity: ComponentActivity,
    val store: LauncherStore,
    val repo: AppRepository,
    val widgets: WidgetController?,
    val ui: LauncherUi,
    /** Current list of launchable apps. */
    val apps: () -> List<AppEntry>,
    val requestPhoto: (PhotoRequest) -> Unit,
) {
    fun toast(msg: String) = Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
}

/** What a picked photo is for. */
sealed interface PhotoRequest {
    data object NewTile : PhotoRequest
    data class ReplaceTile(val itemId: String) : PhotoRequest
    data object Wallpaper : PhotoRequest
}

private val ICON_DP = 58.dp
private val DOCK_ICON_DP = 60.dp
val DockZone = 126.dp

// =============================================================================================
// Home canvas
// =============================================================================================

@Composable
fun HomeCanvas(env: LauncherEnv, apps: Map<String, AppEntry>, modifier: Modifier = Modifier) {
    val ui = env.ui
    val store = env.store
    val state = store.state
    val palette = LocalPalette.current
    val density = LocalDensity.current
    val insets = WindowInsets.systemBars.union(WindowInsets.displayCutout)
    val editScale by animateFloatAsState(if (ui.editing) 0.9f else 1f, tween(260), label = "editScale")

    // Long-press on empty wallpaper starts "arrange" mode; swipe up opens the drawer.
    Box(
        modifier
            .fillMaxSize()
            .swipeUpToOpenDrawer(ui.drawer, enabled = !ui.editing)
            .pointerInput(ui.editing) {
                detectTapGestures(onLongPress = { if (!ui.editing) ui.editing = true })
            },
    )

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(insets)
            .padding(start = 26.dp, end = 26.dp, top = 12.dp, bottom = DockZone)
            .graphicsLayer {
                scaleX = editScale
                scaleY = editScale
                transformOrigin = TransformOrigin(0.5f, 1f)
            },
    ) {
        val o = if (maxWidth > maxHeight) Orient.LAND else Orient.PORT
        val cols = GridSpec.cols(o)
        val rows = GridSpec.rows(o)
        val cellW = maxWidth / cols
        val cellH = maxHeight / rows
        val cellWpx = with(density) { cellW.toPx() }
        val cellHpx = with(density) { cellH.toPx() }
        ui.orient = o
        ui.cellWpx = cellWpx
        ui.cellHpx = cellHpx

        LaunchedEffect(o) { store.ensureCells(o) }

        // The slot a dragged item will drop into.
        val ghost = ui.dropTarget(state.items)
        if (ghost != null && ui.drag != null) {
            Box(
                Modifier
                    .offset { IntOffset((ghost.col * cellWpx).roundToInt(), (ghost.row * cellHpx).roundToInt()) }
                    .size(cellW * ghost.w, cellH * ghost.h)
                    .padding(4.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White.copy(alpha = 0.16f)),
            )
        }

        for (item in state.items) {
            val base = item.cellFor(o)
            // (No early `return@key` here: Kotlin 2.0.21 leaves an invalid NON_LOCAL_RETURN marker in the class.)
            if (base != null) key(item.id) {
                val resize = ui.resize?.takeIf { it.id == item.id }
                val cell = resize?.current ?: base
                val drag = ui.drag?.takeIf { it.id == item.id }
                ItemShell(
                    item = item,
                    cell = cell,
                    apps = apps,
                    env = env,
                    cellW = cellW,
                    cellH = cellH,
                    cellWpx = cellWpx,
                    cellHpx = cellHpx,
                    modifier = Modifier
                        .offset { IntOffset((cell.col * cellWpx).roundToInt(), (cell.row * cellHpx).roundToInt()) }
                        .size(cellW * cell.w, cellH * cell.h)
                        .zIndex(if (drag != null || resize != null) 20f else 1f)
                        .graphicsLayer {
                            if (drag != null) {
                                translationX = drag.offset.x
                                translationY = drag.offset.y
                                scaleX = 1.05f
                                scaleY = 1.05f
                                alpha = 0.94f
                            }
                        },
                )
            }
        }
    }
}

// =============================================================================================
// One item on the canvas: gestures, edit chrome and the content itself
// =============================================================================================

@Composable
private fun ItemShell(
    item: HomeItem,
    cell: Cell,
    apps: Map<String, AppEntry>,
    env: LauncherEnv,
    cellW: androidx.compose.ui.unit.Dp,
    cellH: androidx.compose.ui.unit.Dp,
    cellWpx: Float,
    cellHpx: Float,
    modifier: Modifier,
) {
    val ui = env.ui
    val store = env.store
    val editing = ui.editing
    val app = item.appKey?.let { apps[it] }
    // Items for uninstalled / unavailable apps stay in the layout but are not drawn.
    if (item.kind == ItemKind.APP && app == null) return

    val currentItem by rememberUpdatedState(item)
    val currentCell by rememberUpdatedState(cell)
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val slop = LocalViewConfiguration.current.touchSlop

    val gestures: Modifier = when {
        editing -> Modifier.pointerInput(item.id) {
            detectDragGestures(
                onDragStart = { ui.beginDrag(currentItem, currentCell) },
                onDrag = { change, amount -> change.consume(); ui.dragBy(amount) },
                onDragEnd = { ui.endDrag(store) },
                onDragCancel = { ui.cancelDrag() },
            )
        }.pointerInput(item.id) {
            // Not clickable(): that would merge the remove/resize handles into one accessibility node.
            detectTapGestures(onTap = {
                when (currentItem.kind) {
                    ItemKind.PHOTO -> ui.openSheet(SheetKind.PHOTO, currentItem.id)
                    ItemKind.QUOTE -> ui.openSheet(SheetKind.NOTE, currentItem.id)
                    else -> {}
                }
            })
        }

        item.kind == ItemKind.APP -> Modifier
            .swipeUpToOpenDrawer(ui.drawer, enabled = true)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                // A long-press that opened the menu must not also count as a tap on release.
                if (System.currentTimeMillis() - ui.lastLongPressMs > 400) env.repo.launch(app!!, bounds.toAndroidRect())
            }
            .pointerInput(item.id) {
                var moved = false
                var total = Offset.Zero
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        moved = false
                        total = Offset.Zero
                        ui.lastLongPressMs = System.currentTimeMillis()
                        ui.menu = MenuRequest(MenuKind.APP_HOME, bounds, app = app, item = currentItem)
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        total += amount
                        if (!moved && total.getDistance() > slop * 2) {
                            // The finger is carrying the icon: swap the menu for a drag.
                            moved = true
                            ui.menu = null
                            ui.beginDrag(currentItem, currentCell)
                            ui.dragBy(total)
                        } else if (moved) {
                            ui.dragBy(amount)
                        }
                    },
                    onDragEnd = {
                        ui.lastLongPressMs = System.currentTimeMillis()
                        if (moved) ui.endDrag(store)
                    },
                    onDragCancel = { ui.cancelDrag() },
                )
            }

        item.kind == ItemKind.WIDGET -> Modifier.swipeUpToOpenDrawer(ui.drawer, enabled = true)

        else -> Modifier
            .swipeUpToOpenDrawer(ui.drawer, enabled = true)
            .pointerInput(item.id) { detectTapGestures(onLongPress = { ui.editing = true }) }
    }

    Box(modifier.onGloballyPositioned { bounds = it.boundsInRoot() }.then(gestures)) {
        val padding = when (item.kind) {
            ItemKind.APP -> 0.dp
            ItemKind.CLOCK -> 4.dp
            else -> 5.dp
        }
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .graphicsLayer { rotationZ = item.tilt },
        ) {
            when (item.kind) {
                ItemKind.APP -> AppContent(app!!, env, editing)
                ItemKind.WIDGET -> WidgetContent(item, cell, cellW, cellH, env)
                ItemKind.PHOTO -> PhotoContent(item)
                ItemKind.QUOTE -> QuoteContent(item)
                ItemKind.CLOCK -> ClockContent()
            }
        }
        if (editing) EditChrome(item, cell, env, cellWpx, cellHpx)
    }
}

private fun Rect.toAndroidRect() = android.graphics.Rect(left.toInt(), top.toInt(), right.toInt(), bottom.toInt())

// ---- Edit chrome ----------------------------------------------------------------------------

@Composable
private fun EditChrome(item: HomeItem, cell: Cell, env: LauncherEnv, cellWpx: Float, cellHpx: Float) {
    val ui = env.ui
    val palette = LocalPalette.current
    val widgetMode = if (item.kind == ItemKind.WIDGET) env.widgets?.resizeMode(item.widgetId) else null
    val resizable = when (item.kind) {
        ItemKind.APP -> false
        ItemKind.WIDGET -> widgetMode != null && widgetMode != AppWidgetProviderInfo.RESIZE_NONE
        else -> true
    }
    val currentItem by rememberUpdatedState(item)
    val currentCell by rememberUpdatedState(cell)

    if (item.kind != ItemKind.APP) {
        Canvas(Modifier.fillMaxSize().padding(3.dp)) {
            drawRoundRect(
                color = Color.White.copy(alpha = 0.75f),
                cornerRadius = CornerRadius(24.dp.toPx()),
                size = Size(size.width, size.height),
                style = Stroke(width = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))),
            )
        }
    }

    val removeLabel = when (item.kind) {
        ItemKind.APP -> "Remove from Home"
        ItemKind.WIDGET -> "Remove widget"
        else -> "Remove"
    }
    Box(
        Modifier
            .offset(if (item.kind == ItemKind.APP) 10.dp else (-4).dp, if (item.kind == ItemKind.APP) 6.dp else (-4).dp)
            .size(28.dp)
            .shadow(6.dp, CircleShape)
            .clip(CircleShape)
            .background(Color(0xFFF1EDE6))
            .semantics { contentDescription = removeLabel }
            .clickable {
                when (currentItem.kind) {
                    ItemKind.WIDGET -> env.widgets?.remove(currentItem) ?: env.store.removeItem(currentItem.id)
                    ItemKind.PHOTO -> {
                        env.store.removeItem(currentItem.id)
                        Photos.delete(env.activity, currentItem.photo)
                    }
                    else -> env.store.removeItem(currentItem.id)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (item.kind == ItemKind.APP) Icons.Rounded.Remove else Icons.Rounded.Close,
            contentDescription = null, tint = palette.paperInk, modifier = Modifier.size(16.dp),
        )
    }

    if (resizable) {
        val minSpan = LayoutEngine.minSpan(
            item,
            if (item.kind == ItemKind.WIDGET) env.widgets?.minSpan(item.widgetId) else null,
        )
        val lockW = widgetMode == AppWidgetProviderInfo.RESIZE_VERTICAL
        val lockH = widgetMode == AppWidgetProviderInfo.RESIZE_HORIZONTAL
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) {
            Box(
                Modifier
                    .offset(4.dp, 4.dp)
                    .size(34.dp)
                    .semantics { contentDescription = "Resize" }
                    .pointerInput(item.id) {
                        detectDragGestures(
                            onDragStart = {
                                val c = currentCell
                                ui.beginResize(
                                    currentItem, c, minSpan.first, minSpan.second,
                                    if (lockW) c.w else Int.MAX_VALUE, if (lockH) c.h else Int.MAX_VALUE,
                                )
                            },
                            onDrag = { change, amount -> change.consume(); ui.resizeBy(amount, env.store.state.items) },
                            onDragEnd = { ui.endResize(env.store) },
                            onDragCancel = { ui.resize = null },
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier.size(26.dp).shadow(6.dp, CircleShape).clip(CircleShape).background(Color(0xFFF1EDE6)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.OpenInFull, null, tint = palette.paperInk, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

// =============================================================================================
// Item contents
// =============================================================================================

@Composable
private fun AppContent(app: AppEntry, env: LauncherEnv, editing: Boolean) {
    val palette = LocalPalette.current
    val settings = env.store.state.settings
    val jiggle = if (editing && !LocalReduceMotion.current) {
        val t = rememberInfiniteTransition(label = "jiggle")
        val phase = (app.key.hashCode() and 3) * 40
        t.animateFloat(
            -1.3f, 1.3f,
            infiniteRepeatable(tween(150 + phase, easing = LinearEasing), RepeatMode.Reverse), label = "jiggleAngle",
        ).value
    } else 0f
    Column(
        Modifier.fillMaxSize().graphicsLayer { rotationZ = jiggle }.semantics { contentDescription = app.label },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        AppGlyph(app, settings.iconStyle, palette.glyph, ICON_DP)
        if (settings.showLabels) {
            Text(
                app.label,
                style = labelStyle(palette.glyph),
                maxLines = 1,
                overflow = LabelOverflow,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }
    }
}

@Composable
private fun PhotoContent(item: HomeItem) {
    val palette = LocalPalette.current
    val photo = rememberPhoto(item.photo)
    val art: @Composable () -> Unit = {
        if (photo != null) {
            Image(photo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            ArtScene(palette, item.id.hashCode() and 7, Modifier.fillMaxSize())
        }
    }
    when (item.style) {
        2 -> Box(
            Modifier
                .fillMaxSize()
                .shadow(14.dp, RoundedCornerShape(6.dp), ambientColor = Color(0x40101828), spotColor = Color(0x59101828))
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFF6F2EA))
                .padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 30.dp),
        ) { Box(Modifier.fillMaxSize().clip(RoundedCornerShape(3.dp))) { art() } }

        1 -> {
            val shape = RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 7, bottomStartPercent = 7)
            Box(
                Modifier.fillMaxSize()
                    .shadow(14.dp, shape, ambientColor = Color(0x40101828), spotColor = Color(0x59101828))
                    .clip(shape),
            ) { art() }
        }

        else -> {
            val shape = RoundedCornerShape(26.dp)
            Box(
                Modifier.fillMaxSize()
                    .shadow(14.dp, shape, ambientColor = Color(0x40101828), spotColor = Color(0x59101828))
                    .clip(shape),
            ) { art() }
        }
    }
}

@Composable
private fun QuoteContent(item: HomeItem) {
    val palette = LocalPalette.current
    val card = item.style == 0
    val shape = RoundedCornerShape(26.dp)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val base = min(maxHeight.value, maxWidth.value)
        val lengthFactor = if (item.text.length > 22) 0.78f else 1f
        val size = (base * 0.24f * lengthFactor).coerceIn(15f, 46f)
        Box(
            Modifier
                .fillMaxSize()
                .then(
                    if (card) Modifier
                        .shadow(12.dp, shape, ambientColor = Color(0x33101828), spotColor = Color(0x40101828))
                        .clip(shape)
                        .background(palette.paper)
                    else Modifier,
                )
                .padding(horizontal = 18.dp, vertical = 14.dp),
            contentAlignment = Alignment.BottomStart,
        ) {
            Text(
                item.text,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = size.sp,
                lineHeight = (size * 1.02f).sp,
                color = if (card) palette.paperInk else palette.glyph,
                style = if (card) androidx.compose.ui.text.TextStyle.Default else androidx.compose.ui.text.TextStyle(shadow = SoftShadow),
                maxLines = 4,
                overflow = LabelOverflow,
            )
        }
    }
}

@Composable
private fun ClockContent() {
    val palette = LocalPalette.current
    val context = LocalContext.current
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - value % 60_000L + 30L)
        }
    }
    val is24 = DateFormat.is24HourFormat(context)
    val time = SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault()).format(Date(now))
    val date = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(now)).lowercase(Locale.getDefault())
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val fs = min(maxHeight.value * 0.62f, maxWidth.value * 0.30f).coerceIn(28f, 150f)
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
            Text(
                time,
                fontSize = fs.sp,
                lineHeight = (fs * 1.0f).sp,
                fontWeight = FontWeight.ExtraLight,
                color = palette.glyph,
                style = androidx.compose.ui.text.TextStyle(shadow = SoftShadow),
                maxLines = 1,
            )
            Text(
                date,
                fontSize = (fs * 0.17f).coerceIn(12f, 20f).sp,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.Serif,
                color = palette.glyph.copy(alpha = 0.92f),
                style = androidx.compose.ui.text.TextStyle(shadow = SoftShadow),
                modifier = Modifier.padding(start = 4.dp),
                maxLines = 1,
            )
        }
    }
}

// ---- Native widgets -------------------------------------------------------------------------

/**
 * Hosts an [AppWidgetHostView]. It adds two things the platform view lacks: a long-press hook (so a
 * long-press on a widget can open launcher actions) and a switch that stops the widget from seeing touches
 * while the layout is being edited, so dragging never triggers the widget's own buttons.
 */
class WidgetFrame(context: Context) : FrameLayout(context) {
    var onLongPress: (() -> Unit)? = null
    var blockTouches = false
    private var downX = 0f
    private var downY = 0f
    private var longPressed = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val longPressCheck = Runnable {
        longPressed = true
        onLongPress?.invoke()
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (blockTouches) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                longPressed = false
                postDelayed(longPressCheck, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE ->
                if (Math.hypot((ev.x - downX).toDouble(), (ev.y - downY).toDouble()) > slop) removeCallbacks(longPressCheck)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(longPressCheck)
        }
        return longPressed
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (blockTouches) return false
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
            removeCallbacks(longPressCheck)
            val was = longPressed
            longPressed = false
            return was
        }
        return longPressed
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(longPressCheck)
        super.onDetachedFromWindow()
    }
}

@Composable
private fun WidgetContent(
    item: HomeItem,
    cell: Cell,
    cellW: androidx.compose.ui.unit.Dp,
    cellH: androidx.compose.ui.unit.Dp,
    env: LauncherEnv,
) {
    val controller = env.widgets
    val ui = env.ui
    val id = item.widgetId
    val info = remember(id) { controller?.manager?.getAppWidgetInfo(id) }
    val palette = LocalPalette.current
    if (controller == null || info == null) {
        Frosted(Modifier.fillMaxSize(), RoundedCornerShape(24.dp), elevation = 0.dp) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Widget unavailable", style = labelStyle(palette.glyph))
            }
        }
        return
    }
    // Widgets must be told how much room they have (in dp) so they can pick the right layout.
    val widthDp = (cellW * cell.w).value.roundToInt() - 10
    val heightDp = (cellH * cell.h).value.roundToInt() - 10
    val editing = ui.editing
    AndroidView(
        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)),
        factory = { ctx ->
            val frame = WidgetFrame(ctx)
            controller.createView(id)?.let { host ->
                frame.addView(host, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            }
            frame
        },
        update = { frame ->
            frame.blockTouches = editing
            frame.onLongPress = {
                ui.menu = MenuRequest(MenuKind.WIDGET, Rect(0f, 0f, 1f, 1f), item = item)
                ui.lastLongPressMs = System.currentTimeMillis()
            }
            (frame.getChildAt(0) as? AppWidgetHostView)?.let { controller.notifySize(it, widthDp, heightDp) }
        },
    )
}

// =============================================================================================
// Dock
// =============================================================================================

@Composable
fun DockBar(env: LauncherEnv, apps: Map<String, AppEntry>, modifier: Modifier = Modifier) {
    val ui = env.ui
    val store = env.store
    val palette = LocalPalette.current
    val settings = store.state.settings
    val density = LocalDensity.current
    val entries = store.state.dock.mapNotNull { apps[it] }
    val slotPx = with(density) { (DOCK_ICON_DP + 22.dp).toPx() }
    var dockDrag by remember { mutableStateOf<Pair<Int, Float>?>(null) }

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        // A quiet affordance for the swipe; it is also a tap target for people who can't swipe.
        Box(
            Modifier
                .padding(bottom = 8.dp)
                .size(width = 54.dp, height = 20.dp)
                .semantics { contentDescription = "Open app drawer" }
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { ui.drawer.open() },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(width = 40.dp, height = 4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.5f)))
        }
        Frosted(
            shape = RoundedCornerShape(32.dp),
            tint = Color.White.copy(alpha = 0.17f),
        ) {
            Row(
                Modifier.padding(horizontal = 20.dp, vertical = 11.dp).height(DOCK_ICON_DP + 4.dp).defaultMinSize(minWidth = 120.dp),
                horizontalArrangement = Arrangement.spacedBy(22.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (entries.isEmpty()) {
                    Text("long-press an app to add it here", style = labelStyle(palette.glyph.copy(alpha = 0.8f)))
                }
                entries.forEachIndexed { index, app ->
                    key(app.key) {
                        var bounds by remember { mutableStateOf(Rect.Zero) }
                        val dragging = dockDrag?.takeIf { it.first == index }
                        Box(
                            Modifier
                                .size(DOCK_ICON_DP)
                                .zIndex(if (dragging != null) 5f else 0f)
                                .graphicsLayer {
                                    if (dragging != null) { translationX = dragging.second; scaleX = 1.1f; scaleY = 1.1f }
                                }
                                .onGloballyPositioned { bounds = it.boundsInRoot() }
                                .semantics { contentDescription = app.label }
                                .then(
                                    if (ui.editing) Modifier.pointerInput(app.key, index) {
                                        detectDragGestures(
                                            onDragStart = { dockDrag = index to 0f },
                                            onDrag = { c, a -> c.consume(); dockDrag = dockDrag?.let { it.first to it.second + a.x } },
                                            onDragEnd = {
                                                val d = dockDrag
                                                dockDrag = null
                                                if (d != null) store.moveDock(index, index + (d.second / slotPx).roundToInt())
                                            },
                                            onDragCancel = { dockDrag = null },
                                        )
                                    } else Modifier
                                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                                            if (System.currentTimeMillis() - ui.lastLongPressMs > 400) env.repo.launch(app, bounds.toAndroidRect())
                                        }
                                        .pointerInput(app.key) {
                                            detectTapGestures(onLongPress = {
                                                ui.lastLongPressMs = System.currentTimeMillis()
                                                ui.menu = MenuRequest(MenuKind.APP_DOCK, bounds, app = app)
                                            })
                                        },
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            AppGlyph(app, settings.iconStyle, palette.glyph, DOCK_ICON_DP)
                            if (ui.editing) {
                                Box(
                                    Modifier
                                        .align(Alignment.TopStart)
                                        .offset((-6).dp, (-6).dp)
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFF1EDE6))
                                        .semantics { contentDescription = "Remove ${app.label} from dock" }
                                        .clickable { store.removeFromDock(app.key) },
                                    contentAlignment = Alignment.Center,
                                ) { Icon(Icons.Rounded.Remove, null, tint = palette.paperInk, modifier = Modifier.size(14.dp)) }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =============================================================================================
// Edit bar (floats at the top only while arranging)
// =============================================================================================

@Composable
fun EditBar(env: LauncherEnv, modifier: Modifier = Modifier) {
    val ui = env.ui
    val store = env.store
    val palette = LocalPalette.current
    fun addDecor(template: HomeItem, w: Int, h: Int): HomeItem? {
        val item = store.addDecor(template, ui.orient, w, h)
        if (item == null) env.toast("No room left. Resize or remove something first.")
        return item
    }
    Frosted(modifier, RoundedCornerShape(26.dp), tint = Color.White.copy(alpha = 0.22f), elevation = 14.dp) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BarButton(Icons.Rounded.Widgets, "Widget") { ui.openSheet(SheetKind.WIDGETS) }
            BarButton(Icons.Rounded.Image, "Photo") { env.requestPhoto(PhotoRequest.NewTile) }
            BarButton(Icons.Rounded.Terrain, "Art") {
                addDecor(HomeItem(java.util.UUID.randomUUID().toString(), ItemKind.PHOTO, style = 1), 3, 3)
            }
            BarButton(Icons.Rounded.EditNote, "Note") {
                addDecor(HomeItem(java.util.UUID.randomUUID().toString(), ItemKind.QUOTE, text = "write something kind."), 3, 2)
                    ?.let { ui.openSheet(SheetKind.NOTE, it.id) }
            }
            BarButton(Icons.Rounded.Schedule, "Clock") {
                addDecor(HomeItem(java.util.UUID.randomUUID().toString(), ItemKind.CLOCK), 4, 2)
            }
            BarButton(Icons.Rounded.Apps, "App") { ui.pickApp = true; ui.drawer.open() }
            BarButton(Icons.Rounded.Palette, "Style") { ui.openSheet(SheetKind.STYLE) }
            Box(
                Modifier
                    .padding(start = 6.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(palette.paper)
                    .clickable { ui.editing = false }
                    .padding(horizontal = 14.dp, vertical = 9.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Icon(Icons.Rounded.Check, null, tint = palette.paperInk, modifier = Modifier.size(16.dp))
                    Text("Done", color = palette.paperInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun BarButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    val palette = LocalPalette.current
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = palette.glyph, modifier = Modifier.size(18.dp))
        Text(label, color = palette.glyph, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
