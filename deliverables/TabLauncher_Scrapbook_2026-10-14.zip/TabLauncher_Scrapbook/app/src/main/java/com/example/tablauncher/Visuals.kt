package com.example.tablauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Shadow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

// ---- Backdrop -------------------------------------------------------------------------------

/**
 * The wallpaper surface. When it is the launcher's own backdrop or a chosen photo, glass surfaces
 * (dock, menus, drawer) can re-draw it blurred behind themselves. With the system wallpaper the
 * launcher cannot read the pixels, so glass falls back to plain translucency.
 */
val LocalBackdrop = compositionLocalOf<(@Composable () -> Unit)?> { null }
val LocalRootSize = compositionLocalOf { IntSize.Zero }

/** True when the user turned system animations off (Settings > Accessibility > Remove animations). */
val LocalReduceMotion = compositionLocalOf { false }

@Composable
fun BackdropArt(palette: Palette, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val big = max(w, h)
        drawRect(
            Brush.linearGradient(
                listOf(palette.c0, palette.c1, palette.c2),
                start = Offset(0f, 0f), end = Offset(w, h),
            ),
        )
        // Warm bloom from the lower right, a cool one from the lower left, a pale light top left.
        drawRect(Brush.radialGradient(listOf(palette.glow.copy(alpha = 0.92f), palette.glow.copy(alpha = 0f)), Offset(w * 0.96f, h * 1.0f), big * 0.62f))
        drawRect(Brush.radialGradient(listOf(palette.bloom.copy(alpha = 0.55f), palette.bloom.copy(alpha = 0f)), Offset(w * 0.05f, h * 0.98f), big * 0.5f))
        drawRect(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0f)), Offset(w * 0.12f, h * 0.05f), big * 0.45f))
        // Two very faint folds, like creased paper.
        val fold1 = Path().apply { moveTo(w * 0.30f, 0f); lineTo(w * 0.62f, 0f); lineTo(w * 0.18f, h); lineTo(0f, h); lineTo(0f, h * 0.55f); close() }
        drawPath(fold1, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.07f), Color.White.copy(alpha = 0f)), Offset(w * 0.3f, 0f), Offset(0f, h)))
        val fold2 = Path().apply { moveTo(w, h * 0.12f); lineTo(w, h * 0.62f); lineTo(w * 0.55f, h); lineTo(w * 0.40f, h); close() }
        drawPath(fold2, Brush.linearGradient(listOf(Color.Black.copy(alpha = 0.06f), Color.Black.copy(alpha = 0f)), Offset(w, h * 0.3f), Offset(w * 0.4f, h)))
    }
}

@Composable
fun PhotoBackdrop(file: String?, palette: Palette, modifier: Modifier = Modifier) {
    val photo = rememberPhoto(file)
    Box(modifier.fillMaxSize()) {
        BackdropArt(palette)
        if (photo != null) {
            Image(photo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            // A touch of colour so any photo sits comfortably with the glyphs.
            Box(Modifier.fillMaxSize().background(palette.c0.copy(alpha = 0.16f)))
        }
    }
}

@Composable
fun WallpaperSurface(settings: LauncherSettings, palette: Palette, modifier: Modifier = Modifier) {
    when (settings.wallpaper) {
        WallpaperMode.BACKDROP -> BackdropArt(palette, modifier)
        WallpaperMode.PHOTO -> PhotoBackdrop(settings.wallpaperPhoto, palette, modifier)
        WallpaperMode.SYSTEM -> Box(
            modifier.fillMaxSize().background(
                // Legibility scrim only; the real wallpaper shows through the transparent window.
                Brush.verticalGradient(listOf(Color(0x33000000), Color(0x00000000), Color(0x4D000000))),
            ),
        )
    }
}

// ---- Glass ----------------------------------------------------------------------------------

/**
 * A translucent frosted surface. Where the backdrop is known and the OS supports RenderEffect (Android
 * 12+) it blurs the wallpaper behind itself; otherwise it is simply translucent, which still reads as
 * glass over a soft wallpaper.
 */
@Composable
fun Frosted(
    modifier: Modifier = Modifier,
    shape: Shape,
    tint: Color = Color.White.copy(alpha = 0.18f),
    blurRadius: Dp = 26.dp,
    elevation: Dp = 12.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val backdrop = LocalBackdrop.current
    val root = LocalRootSize.current
    val density = LocalDensity.current
    var pos by remember { mutableStateOf(IntOffset.Zero) }
    val canBlur = backdrop != null && Build.VERSION.SDK_INT >= 31 && root != IntSize.Zero
    Box(
        modifier
            .shadow(elevation, shape, ambientColor = Color(0x33101828), spotColor = Color(0x40101828))
            .clip(shape)
            .onGloballyPositioned { c ->
                val p = c.positionInRoot()
                pos = IntOffset(p.x.toInt(), p.y.toInt())
            },
    ) {
        if (canBlur) {
            Box(
                Modifier
                    .matchParentSize()
                    .wrapContentSize(Alignment.TopStart, unbounded = true)
                    .offset { IntOffset(-pos.x, -pos.y) }
                    .size(with(density) { root.width.toDp() }, with(density) { root.height.toDp() })
                    .blur(blurRadius, BlurredEdgeTreatment.Unbounded),
            ) { backdrop?.invoke() }
        }
        Box(Modifier.matchParentSize().background(if (canBlur) tint else tint.copy(alpha = min(1f, tint.alpha + 0.10f))))
        Box(
            Modifier.matchParentSize().border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.22f))),
                shape,
            ),
        )
        content()
    }
}

// ---- Paper-cut artwork (placeholder for photo tiles) -----------------------------------------

@Composable
fun ArtScene(palette: Palette, variant: Int, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFFD7D3E4), Color(0xFFF2E6D0))))
        val sun = Offset(w * (if (variant % 2 == 0) 0.66f else 0.34f), h * 0.34f)
        drawCircle(Color(0xFFFFF3DA), radius = min(w, h) * 0.17f, center = sun)
        drawCircle(Color(0xFFFFF3DA).copy(alpha = 0.35f), radius = min(w, h) * 0.26f, center = sun)
        fun hill(color: Color, base: Float, amp: Float, shift: Float) {
            val p = Path()
            p.moveTo(0f, h)
            p.lineTo(0f, h * base)
            val steps = 4
            for (i in 1..steps) {
                val x0 = w * (i - 1) / steps
                val x1 = w * i / steps
                val dir = if ((i + variant) % 2 == 0) -1f else 1f
                p.cubicTo(x0 + (x1 - x0) * 0.4f, h * (base + dir * amp + shift), x0 + (x1 - x0) * 0.6f, h * (base - dir * amp + shift), x1, h * (base + shift * (i % 2)))
            }
            p.lineTo(w, h)
            p.close()
            drawPath(p, color)
        }
        hill(palette.c0.copy(alpha = 0.55f), 0.50f, 0.07f, 0.00f)
        hill(palette.c1.copy(alpha = 0.78f), 0.64f, 0.06f, 0.02f)
        hill(palette.bloom.copy(alpha = 0.95f), 0.78f, 0.05f, -0.02f)
        hill(palette.c0.copy(alpha = 0.85f), 0.92f, 0.03f, 0.01f)
    }
}

// ---- Photos ---------------------------------------------------------------------------------

object Photos {
    private const val MAX_EDGE = 1600
    private val cache = LruCache<String, ImageBitmap>(12)

    private fun dir(context: Context) = File(context.filesDir, "photos").apply { mkdirs() }

    /** Copies a picked image into app storage, downscaled and rotated upright. Returns the stored file name. */
    suspend fun import(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_EDGE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return@runCatching null
            val rotation = resolver.openInputStream(uri)?.use {
                when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            } ?: 0f
            val scale = min(1f, MAX_EDGE.toFloat() / max(bmp.width, bmp.height))
            if (rotation != 0f || scale < 1f) {
                val m = Matrix().apply { postRotate(rotation); postScale(scale, scale) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val name = UUID.randomUUID().toString() + ".jpg"
            File(dir(context), name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            name
        }.getOrNull()
    }

    fun delete(context: Context, name: String?) {
        if (name != null) runCatching { File(dir(context), name).delete() }
    }

    suspend fun load(context: Context, name: String): ImageBitmap? {
        cache.get(name)?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching { BitmapFactory.decodeFile(File(dir(context), name).path)?.asImageBitmap() }.getOrNull()
        }?.also { cache.put(name, it) }
    }
}

@Composable
fun rememberPhoto(name: String?): ImageBitmap? {
    if (name == null) return null
    val context = androidx.compose.ui.platform.LocalContext.current
    val img by produceState<ImageBitmap?>(null, name) { value = Photos.load(context, name) }
    return img
}

// ---- Text helpers ---------------------------------------------------------------------------

val SoftShadow = Shadow(Color(0x73101828), Offset(0f, 2f), 7f)

fun labelStyle(color: Color) = TextStyle(
    color = color,
    fontSize = 11.5.sp,
    shadow = SoftShadow,
)

val LabelOverflow = TextOverflow.Ellipsis
