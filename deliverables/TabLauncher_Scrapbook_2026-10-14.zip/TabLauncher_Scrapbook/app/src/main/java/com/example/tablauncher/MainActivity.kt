package com.example.tablauncher

import android.content.Intent
import android.content.pm.LauncherApps
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * The home activity. Kept deliberately thin: it owns the things that must live on an Activity
 * (AppWidgetHost, result launchers, package callbacks, the HOME-button signal) and hands everything
 * else to Compose.
 */
class MainActivity : ComponentActivity() {
    private lateinit var store: LauncherStore
    internal lateinit var repo: AppRepository
    private lateinit var widgets: WidgetController
    private var packageCallback: LauncherApps.Callback? = null

    /** Bumped whenever the set of installed apps changes. */
    private var appsTick by mutableIntStateOf(0)

    /** Bumped when the HOME button is pressed while the launcher is already showing. */
    private var homeSignal by mutableIntStateOf(0)

    /** Lets tests supply a fixed app list instead of querying the (empty) test device. */
    internal var appsOverride by mutableStateOf<List<AppEntry>?>(null)

    /** Set from composition so tests and callbacks can reach the live UI state. */
    internal var env: LauncherEnv? = null

    private var photoRequest: PhotoRequest? = null

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val request = photoRequest
        photoRequest = null
        if (uri == null || request == null) return@registerForActivityResult
        lifecycleScope.launch {
            val name = Photos.import(this@MainActivity, uri)
            if (name == null) {
                Toast.makeText(this@MainActivity, "That picture couldn't be loaded.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            applyPhoto(request, name)
        }
    }

    private fun applyPhoto(request: PhotoRequest, name: String) {
        val orient = env?.ui?.orient ?: Orient.LAND
        when (request) {
            PhotoRequest.NewTile -> {
                val item = HomeItem(UUID.randomUUID().toString(), ItemKind.PHOTO, photo = name)
                if (store.addDecor(item, orient, 3, 3) == null) {
                    Photos.delete(this, name)
                    Toast.makeText(this, "No room left. Resize or remove something first.", Toast.LENGTH_SHORT).show()
                }
            }
            is PhotoRequest.ReplaceTile -> {
                val old = store.item(request.itemId)?.photo
                store.updateItem(request.itemId) { it.copy(photo = name) }
                if (old != name) Photos.delete(this, old)
            }
            PhotoRequest.Wallpaper -> {
                val old = store.state.settings.wallpaperPhoto
                store.updateSettings { it.copy(wallpaper = WallpaperMode.PHOTO, wallpaperPhoto = name) }
                Photos.delete(this, old)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        store = LauncherStore(this)
        repo = AppRepository(this)
        widgets = WidgetController(this, store)
        widgets.cleanUpInterruptedAdd()
        packageCallback = repo.registerCallback { appsTick++ }

        setContent {
            val scope = rememberCoroutineScope()
            val ui = remember { LauncherUi(scope) }

            val loaded by produceState(emptyList<AppEntry>(), appsTick) {
                value = withContext(Dispatchers.IO) { repo.load() }
            }
            val apps = appsOverride ?: loaded

            val launcherEnv = remember(ui) {
                LauncherEnv(
                    activity = this@MainActivity,
                    store = store,
                    repo = repo,
                    widgets = widgets,
                    ui = ui,
                    apps = { appsOverride ?: loaded },
                    requestPhoto = { request ->
                        photoRequest = request
                        pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                )
            }
            SideEffect { env = launcherEnv }

            // First run / migration, and clean-up of apps that really are gone.
            LaunchedEffect(apps) {
                store.onAppsLoaded(apps) { id -> widgets.spanForId(id) }
                if (apps.isNotEmpty()) store.pruneUninstalled { key -> repo.stillInstalled(key) }
            }
            LaunchedEffect(homeSignal) { if (homeSignal > 0) ui.goHome() }

            LauncherRoot(launcherEnv, apps)
        }
    }

    override fun onStart() {
        super.onStart()
        widgets.start()
    }

    override fun onStop() {
        widgets.stop()
        super.onStop()
    }

    override fun onDestroy() {
        packageCallback?.let { repo.unregisterCallback(it) }
        super.onDestroy()
    }

    /** HOME pressed while we are already the foreground launcher (launchMode=singleTask). */
    public override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) homeSignal++
    }

    @Deprecated("Needed for the AppWidget configure activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == WidgetController.REQUEST_CONFIGURE) {
            widgets.onConfigureResult(resultCode, data)
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }
}
