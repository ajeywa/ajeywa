package com.example.tablauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Dock
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val Danger = Color(0xFFFFB4A8)

// =============================================================================================
// Long-press menu
// =============================================================================================

private class MenuRow(val icon: ImageVector?, val label: String, val danger: Boolean = false, val action: () -> Unit)

@Composable
fun ContextMenuLayer(env: LauncherEnv, apps: Map<String, AppEntry>) {
    val ui = env.ui
    val req = ui.menu
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = req != null,
            enter = fadeIn(tween(120)) + scaleIn(tween(160), initialScale = 0.92f),
            exit = fadeOut(tween(90)) + scaleOut(tween(90), targetScale = 0.96f),
        ) {
            // Keep the last request around while the exit animation plays.
            val shown = remember(req) { req }
            if (shown != null) MenuPanel(env, shown)
        }
    }
}

@Composable
private fun MenuPanel(env: LauncherEnv, req: MenuRequest) {
    val ui = env.ui
    val store = env.store
    val palette = LocalPalette.current
    val density = LocalDensity.current
    val root = LocalRootSize.current
    val app = req.app
    val shortcuts by produceState(emptyList<ShortcutEntry>(), app?.key) {
        value = if (app != null) withContext(Dispatchers.IO) { env.repo.shortcuts(app) } else emptyList()
    }

    val rows = buildList {
        when (req.kind) {
            MenuKind.WIDGET -> {
                val item = req.item!!
                add(MenuRow(Icons.Rounded.OpenWith, "Move & resize") { ui.menu = null; ui.editing = true })
                add(MenuRow(Icons.Rounded.Delete, "Remove widget", danger = true) {
                    ui.menu = null
                    env.widgets?.remove(item) ?: store.removeItem(item.id)
                })
            }
            else -> {
                app!!
                add(MenuRow(Icons.Rounded.Info, "App info") { ui.menu = null; env.repo.openAppInfo(app, req.anchor.toAndroid()) })
                if (env.repo.canUninstall(app)) {
                    add(MenuRow(Icons.Rounded.Delete, "Uninstall", danger = true) { ui.menu = null; env.repo.uninstall(app) })
                }
                when (req.kind) {
                    MenuKind.APP_HOME -> {
                        add(MenuRow(Icons.Rounded.OpenWith, "Edit Home screen") { ui.menu = null; ui.editing = true })
                        if (!store.isInDock(app.key)) add(MenuRow(Icons.Rounded.Dock, "Add to Dock") {
                            ui.menu = null
                            if (!store.addToDock(app.key)) env.toast("The Dock is full")
                        })
                        add(MenuRow(Icons.Rounded.Remove, "Remove from Home") {
                            ui.menu = null
                            req.item?.let { store.removeItem(it.id) }
                        })
                    }
                    MenuKind.APP_DOCK -> {
                        add(MenuRow(Icons.Rounded.OpenWith, "Edit Home screen") { ui.menu = null; ui.editing = true })
                        add(MenuRow(Icons.Rounded.Remove, "Remove from Dock") { ui.menu = null; store.removeFromDock(app.key) })
                    }
                    else -> {
                        if (!store.isOnHome(app.key)) add(MenuRow(Icons.Rounded.Add, "Add to Home") {
                            ui.menu = null
                            if (!store.addApp(app.key, ui.orient)) env.toast("No room left on Home")
                            else env.toast("${app.label} added to Home")
                        })
                        if (store.isInDock(app.key)) {
                            add(MenuRow(Icons.Rounded.Remove, "Remove from Dock") { ui.menu = null; store.removeFromDock(app.key) })
                        } else {
                            add(MenuRow(Icons.Rounded.Dock, "Add to Dock") {
                                ui.menu = null
                                if (!store.addToDock(app.key)) env.toast("The Dock is full")
                            })
                        }
                    }
                }
            }
        }
    }

    val marginPx = with(density) { 16.dp.toPx() }
    val panelW = 260.dp
    val panelWpx = with(density) { panelW.toPx() }
    var size by remember { mutableStateOf(IntSize(panelWpx.roundToInt(), with(density) { 220.dp.roundToPx() })) }

    // Tapping anywhere outside the panel closes it.
    Box(
        Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { ui.menu = null } },
    ) {
        val a = req.anchor
        val x = (a.center.x - size.width / 2f).coerceIn(marginPx, (root.width - size.width - marginPx).coerceAtLeast(marginPx))
        val below = a.bottom + marginPx / 2f
        val fitsBelow = below + size.height < root.height - marginPx * 2
        val y = if (req.kind == MenuKind.WIDGET) (a.center.y - size.height / 2f).coerceIn(marginPx * 3, (root.height - size.height - marginPx * 4).coerceAtLeast(marginPx * 3))
        else if (fitsBelow) below else (a.top - size.height - marginPx / 2f).coerceAtLeast(marginPx * 2)

        Frosted(
            Modifier
                .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
                .width(panelW)
                .onSizeChanged { size = it }
                .pointerInput(Unit) { detectTapGestures { } },
            RoundedCornerShape(24.dp),
            tint = palette.c0.copy(alpha = 0.55f),
            blurRadius = 30.dp,
            elevation = 18.dp,
        ) {
            Column(Modifier.padding(vertical = 8.dp)) {
                if (app != null) {
                    Row(
                        Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        AppGlyph(app, store.state.settings.iconStyle, palette.glyph, 32.dp)
                        Text(app.label, color = palette.glyph, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                    shortcuts.forEach { sc ->
                        MenuItem(null, sc.label, false) { ui.menu = null; env.repo.startShortcut(sc) }
                    }
                    if (shortcuts.isNotEmpty()) Box(Modifier.padding(vertical = 4.dp, horizontal = 16.dp).fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.18f)))
                }
                rows.forEach { MenuItem(it.icon, it.label, it.danger, it.action) }
            }
        }
    }
}

@Composable
private fun MenuItem(icon: ImageVector?, label: String, danger: Boolean, onClick: () -> Unit) {
    val palette = LocalPalette.current
    val color = if (danger) Danger else palette.glyph
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (icon != null) Icon(icon, null, tint = color, modifier = Modifier.size(20.dp)) else Spacer(Modifier.size(20.dp))
        Text(label, color = color, fontSize = 15.sp)
    }
}

private fun Rect.toAndroid() = android.graphics.Rect(left.toInt(), top.toInt(), right.toInt(), bottom.toInt())

// =============================================================================================
// Bottom sheets
// =============================================================================================

@Composable
fun SheetLayer(env: LauncherEnv) {
    val ui = env.ui
    val visible = ui.sheet != SheetKind.NONE
    val insets = WindowInsets.systemBars.union(WindowInsets.displayCutout)
    // Remember the last sheet so its content stays during the exit animation.
    var lastKind by remember { mutableStateOf(SheetKind.WIDGETS) }
    if (visible) lastKind = ui.sheet
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(tween(160)), exit = fadeOut(tween(140))) {
            Box(
                Modifier.fillMaxSize().background(Color(0x59101828)).pointerInput(Unit) { detectTapGestures { ui.closeSheet() } },
            )
        }
        AnimatedVisibility(
            visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(260)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(160)),
        ) {
            val palette = LocalPalette.current
            Frosted(
                Modifier
                    .padding(horizontal = 16.dp)
                    .windowInsetsPadding(insets)
                    .padding(bottom = 12.dp)
                    .widthIn(max = 680.dp)
                    .fillMaxWidth()
                    .imePadding()
                    .pointerInput(Unit) { detectTapGestures { } },
                RoundedCornerShape(30.dp),
                tint = palette.c0.copy(alpha = 0.66f),
                blurRadius = 36.dp,
                elevation = 20.dp,
            ) {
                Column(Modifier.padding(horizontal = 22.dp, vertical = 16.dp)) {
                    when (lastKind) {
                        SheetKind.WIDGETS -> WidgetPickerSheet(env)
                        SheetKind.STYLE -> StyleSheet(env)
                        SheetKind.PHOTO -> PhotoSheet(env)
                        SheetKind.NOTE -> NoteSheet(env)
                        SheetKind.NONE -> {}
                    }
                }
            }
        }
    }
}

@Composable
private fun SheetTitle(text: String, trailing: (@Composable () -> Unit)? = null) {
    val palette = LocalPalette.current
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = palette.glyph, fontSize = 20.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Serif, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val palette = LocalPalette.current
    Box(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) palette.paper else Color.White.copy(alpha = 0.14f))
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 9.dp),
    ) {
        Text(label, color = if (selected) palette.paperInk else palette.glyph, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Label(text: String) {
    val palette = LocalPalette.current
    Text(text, color = palette.glyph.copy(alpha = 0.75f), fontSize = 12.sp, letterSpacing = 1.2.sp, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
}

// ---- Widget picker --------------------------------------------------------------------------

@Composable
private fun WidgetPickerSheet(env: LauncherEnv) {
    val palette = LocalPalette.current
    val controller = env.widgets
    val choices by produceState<List<WidgetChoice>?>(null) {
        value = withContext(Dispatchers.IO) { controller?.loadChoices().orEmpty() }
    }
    SheetTitle("Add a widget")
    Text(
        "Widgets are real Android widgets. Their inside is drawn by the app that made them; Tab Launcher controls where they sit and how big they are.",
        color = palette.glyph.copy(alpha = 0.8f), fontSize = 12.5.sp, modifier = Modifier.padding(bottom = 10.dp),
    )
    val list = choices
    when {
        list == null -> Text("loading…", color = palette.glyph)
        list.isEmpty() -> Text("No widgets are available on this device.", color = palette.glyph)
        else -> LazyColumn(Modifier.heightIn(max = 420.dp)) {
            items(list, key = { it.info.provider.flattenToString() + it.info.profile.hashCode() }) { choice ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { env.ui.closeSheet(); controller?.add(choice) }
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Box(
                        Modifier.size(width = 84.dp, height = 60.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        val bmp = remember(choice) { choice.preview?.let { drawableToBitmap(it) } }
                        if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize().padding(4.dp), contentScale = ContentScale.Fit)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(choice.label, color = palette.glyph, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                        Text(choice.appLabel, color = palette.glyph.copy(alpha = 0.7f), fontSize = 12.sp, maxLines = 1)
                    }
                    Text("${choice.spanW} × ${choice.spanH}", color = palette.glyph.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }
        }
    }
}

private fun drawableToBitmap(d: android.graphics.drawable.Drawable): android.graphics.Bitmap? = runCatching {
    val w = d.intrinsicWidth.coerceIn(1, 480)
    val h = d.intrinsicHeight.coerceIn(1, 480)
    val b = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(b)
    d.setBounds(0, 0, w, h)
    d.draw(c)
    b
}.getOrNull()

// ---- Style ----------------------------------------------------------------------------------

@Composable
private fun StyleSheet(env: LauncherEnv) {
    val palette = LocalPalette.current
    val store = env.store
    val s = store.state.settings
    SheetTitle("Style")
    Label("PALETTE")
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Palettes.forEachIndexed { i, p ->
            Column(
                Modifier.clickable { store.updateSettings { it.copy(palette = i) } },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(p.c0, p.c1, p.c2)))
                        .border(if (s.palette == i) 2.5.dp else 1.dp, if (s.palette == i) Color.White else Color.White.copy(alpha = 0.4f), CircleShape),
                )
                Text(p.name.lowercase(), color = palette.glyph, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
    Label("WALLPAPER")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Backdrop", s.wallpaper == WallpaperMode.BACKDROP) { store.updateSettings { it.copy(wallpaper = WallpaperMode.BACKDROP) } }
        Chip("System wallpaper", s.wallpaper == WallpaperMode.SYSTEM) { store.updateSettings { it.copy(wallpaper = WallpaperMode.SYSTEM) } }
        Chip(if (s.wallpaperPhoto != null) "My photo" else "Choose a photo…", s.wallpaper == WallpaperMode.PHOTO) {
            if (s.wallpaperPhoto != null) store.updateSettings { it.copy(wallpaper = WallpaperMode.PHOTO) }
            else env.requestPhoto(PhotoRequest.Wallpaper)
        }
        if (s.wallpaperPhoto != null) Chip("Change photo", false) { env.requestPhoto(PhotoRequest.Wallpaper) }
    }
    if (s.wallpaper == WallpaperMode.SYSTEM) {
        Text(
            "Blur behind the dock and menus needs the launcher's own backdrop or a photo; with the system wallpaper they stay plain glass.",
            color = palette.glyph.copy(alpha = 0.7f), fontSize = 11.5.sp, modifier = Modifier.padding(top = 6.dp),
        )
    }
    Label("ICONS")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Glyph", s.iconStyle == IconStyle.GLYPH) { store.updateSettings { it.copy(iconStyle = IconStyle.GLYPH) } }
        Chip("Original colours", s.iconStyle == IconStyle.ORIGINAL) { store.updateSettings { it.copy(iconStyle = IconStyle.ORIGINAL) } }
        Chip(if (s.showLabels) "Labels on" else "Labels off", s.showLabels) { store.updateSettings { it.copy(showLabels = !it.showLabels) } }
    }
    Label("HOME")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Make this my home app", false) { AppRepository.startHomeSettings(env.activity) }
        Chip("Reset layout", false) {
            store.resetLayout(env.apps())
            env.ui.closeSheet()
        }
    }
}

// ---- Photo tile -----------------------------------------------------------------------------

@Composable
private fun PhotoSheet(env: LauncherEnv) {
    val ui = env.ui
    val store = env.store
    val id = ui.sheetItemId ?: return
    val item = store.item(id) ?: return
    SheetTitle("Photo tile")
    Label("FRAME")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Rounded", "Arch", "Polaroid").forEachIndexed { i, name ->
            Chip(name, item.style == i) {
                store.updateItem(id) { it.copy(style = i, tilt = if (i == 2 && it.tilt == 0f) -3f else if (i != 2) 0f else it.tilt) }
            }
        }
    }
    Label("PICTURE")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Choose a photo…", false) { env.requestPhoto(PhotoRequest.ReplaceTile(id)) }
        if (item.photo != null) Chip("Use artwork instead", false) {
            Photos.delete(env.activity, item.photo)
            store.updateItem(id) { it.copy(photo = null) }
        }
        Chip("Done", true) { ui.closeSheet() }
    }
}

// ---- Note tile ------------------------------------------------------------------------------

@Composable
private fun NoteSheet(env: LauncherEnv) {
    val palette = LocalPalette.current
    val ui = env.ui
    val store = env.store
    val id = ui.sheetItemId ?: return
    val item = store.item(id) ?: return
    var text by remember(id) { mutableStateOf(item.text) }
    SheetTitle("Note")
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.14f)).padding(16.dp),
    ) {
        BasicTextField(
            value = text,
            onValueChange = { text = it.take(80); store.updateItem(id) { i -> i.copy(text = text) } },
            textStyle = TextStyle(color = palette.glyph, fontSize = 18.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Serif),
            cursorBrush = SolidColor(palette.glyph),
            modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Note text" },
        )
    }
    Label("LOOK")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Paper card", item.style == 0) { store.updateItem(id) { it.copy(style = 0) } }
        Chip("Bare text", item.style == 1) { store.updateItem(id) { it.copy(style = 1) } }
        Chip("Done", true) { ui.closeSheet() }
    }
}
