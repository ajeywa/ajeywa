package com.example.tablauncher

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitVerticalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.verticalDrag
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * 0 = closed, 1 = fully open. The drawer follows the finger while it is being dragged and then settles
 * with a spring, taking the release velocity into account.
 */
class DrawerController(private val scope: CoroutineScope) {
    var progress by mutableFloatStateOf(0f)
        private set
    private var job: Job? = null
    private var dragStart = 0f

    val isVisible: Boolean get() = progress > 0.001f
    val isOpen: Boolean get() = progress > 0.5f

    fun beginDrag() {
        job?.cancel()
        dragStart = progress
    }

    fun dragBy(deltaProgress: Float) {
        progress = (progress + deltaProgress).coerceIn(0f, 1f)
    }

    /** [velocityPxPerSec] is the vertical finger velocity (negative = upwards); [travelPx] the full travel. */
    fun settle(velocityPxPerSec: Float, travelPx: Float) {
        val open = when {
            velocityPxPerSec < -700f -> true
            velocityPxPerSec > 700f -> false
            dragStart > 0.5f -> progress > 0.78f
            else -> progress > 0.22f
        }
        animateTo(if (open) 1f else 0f, -velocityPxPerSec / travelPx.coerceAtLeast(1f))
    }

    fun open() = animateTo(1f)
    fun close() = animateTo(0f)

    /** Jump without animation (used when Home is pressed so the next look is always the home screen). */
    fun snapClosed() {
        job?.cancel()
        progress = 0f
    }

    private fun animateTo(target: Float, velocity: Float = 0f) {
        job?.cancel()
        job = scope.launch {
            animate(
                initialValue = progress,
                targetValue = target,
                initialVelocity = velocity,
                animationSpec = spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMediumLow),
            ) { value, _ -> progress = value.coerceIn(0f, 1f) }
        }
    }
}

/**
 * Swipe up from the lower part of Home (or any empty/non-interactive part of it) to pull the drawer up.
 * It only claims a gesture after the touch slop is exceeded in the upward direction, so taps and
 * long-presses on icons are untouched, and gestures that a child (e.g. a scrolling widget) consumed
 * are left alone. The system gesture area at the very bottom edge is never intercepted by apps.
 */
fun Modifier.swipeUpToOpenDrawer(drawer: DrawerController, enabled: Boolean): Modifier =
    if (!enabled) this else pointerInput(drawer) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            val tracker = VelocityTracker()
            tracker.addPosition(down.uptimeMillis, down.position)
            var upward = false
            var startDy = 0f
            val travel = size.height.toFloat().coerceAtLeast(1f)
            val claimed = awaitVerticalTouchSlopOrCancellation(down.id) { change, over ->
                if (over < 0f) {
                    upward = true
                    startDy = over
                    change.consume()
                }
            }
            if (claimed == null || !upward) return@awaitEachGesture
            drawer.beginDrag()
            drawer.dragBy(-startDy / travel)
            verticalDrag(claimed.id) { change ->
                tracker.addPosition(change.uptimeMillis, change.position)
                drawer.dragBy(-change.positionChange().y / travel)
                change.consume()
            }
            drawer.settle(tracker.calculateVelocity().y, travel)
        }
    }

// ---- Drag / resize / menus --------------------------------------------------------------------

class DragState(val id: String, val start: Cell, val offset: Offset, val dragging: Boolean)

class ResizeState(
    val id: String,
    val start: Cell,
    val current: Cell,
    val dx: Float,
    val dy: Float,
    val minW: Int,
    val minH: Int,
    val maxW: Int,
    val maxH: Int,
)

enum class MenuKind { APP_HOME, APP_DOCK, APP_DRAWER, WIDGET }

class MenuRequest(
    val kind: MenuKind,
    val anchor: Rect,
    val app: AppEntry? = null,
    val item: HomeItem? = null,
)

enum class SheetKind { NONE, WIDGETS, STYLE, PHOTO, NOTE }

/** All transient UI state of the launcher in one place so the composables stay small. */
class LauncherUi(scope: CoroutineScope) {
    val drawer = DrawerController(scope)

    var editing by mutableStateOf(false)
    var menu by mutableStateOf<MenuRequest?>(null)
    var sheet by mutableStateOf(SheetKind.NONE)
    var sheetItemId by mutableStateOf<String?>(null)
    /** When true, tapping an app in the drawer places it on Home instead of launching it. */
    var pickApp by mutableStateOf(false)

    var drag by mutableStateOf<DragState?>(null)
    var resize by mutableStateOf<ResizeState?>(null)

    // Geometry of the home canvas, refreshed every composition so gesture callbacks never read stale values.
    var orient: Orient = Orient.LAND
    var cellWpx: Float = 1f
    var cellHpx: Float = 1f

    /** Wall-clock time of the last long-press, used to ignore the click that can follow its release. */
    var lastLongPressMs: Long = 0L

    val anyOverlay: Boolean
        get() = menu != null || sheet != SheetKind.NONE || drawer.isVisible || editing

    fun openSheet(kind: SheetKind, itemId: String? = null) {
        menu = null
        sheet = kind
        sheetItemId = itemId
    }

    fun closeSheet() {
        sheet = SheetKind.NONE
        sheetItemId = null
    }

    /** Closes everything that sits above the plain home screen. Used by the Home button. */
    fun goHome() {
        menu = null
        sheet = SheetKind.NONE
        sheetItemId = null
        editing = false
        pickApp = false
        drag = null
        resize = null
        drawer.snapClosed()
    }

    // ---- dragging ---------------------------------------------------------------------------

    fun beginDrag(item: HomeItem, start: Cell) {
        drag = DragState(item.id, start, Offset.Zero, dragging = true)
    }

    fun dragBy(delta: Offset) {
        drag = drag?.let { DragState(it.id, it.start, it.offset + delta, it.dragging) }
    }

    fun cancelDrag() { drag = null }

    /** Where the dragged item would land if released now. */
    fun dropTarget(items: List<HomeItem>): Cell? {
        val d = drag ?: return null
        val wanted = Cell(
            d.start.col + (d.offset.x / cellWpx).roundToInt(),
            d.start.row + (d.offset.y / cellHpx).roundToInt(),
            d.start.w, d.start.h,
        )
        return LayoutEngine.findFreeNear(wanted, items, orient, d.id)
    }

    fun endDrag(store: LauncherStore) {
        val target = dropTarget(store.state.items)
        val d = drag
        drag = null
        if (d != null && target != null && target != d.start) store.moveItem(d.id, orient, target)
    }

    // ---- resizing ---------------------------------------------------------------------------

    fun beginResize(item: HomeItem, start: Cell, minW: Int, minH: Int, maxW: Int, maxH: Int) {
        resize = ResizeState(item.id, start, start, 0f, 0f, minW, minH, maxW, maxH)
    }

    fun resizeBy(delta: Offset, items: List<HomeItem>) {
        val r = resize ?: return
        val item = items.firstOrNull { it.id == r.id } ?: return
        val dx = r.dx + delta.x
        val dy = r.dy + delta.y
        val wantW = ((r.start.w * cellWpx + dx) / cellWpx).roundToInt()
        val wantH = ((r.start.h * cellHpx + dy) / cellHpx).roundToInt()
        val cand = LayoutEngine.resolveResize(
            item, orient, items, wantW.coerceIn(r.minW, r.maxW), wantH.coerceIn(r.minH, r.maxH), r.minW, r.minH, r.maxW, r.maxH,
        ) ?: r.current
        resize = ResizeState(r.id, r.start, cand, dx, dy, r.minW, r.minH, r.maxW, r.maxH)
    }

    fun endResize(store: LauncherStore) {
        val r = resize
        resize = null
        if (r != null && r.current != r.start) store.resizeItem(r.id, orient, r.current)
    }
}
