package com.example.tablauncher

/** Pure grid logic: no Android or Compose dependencies, so it is unit-tested on the JVM. */
object LayoutEngine {

    private fun occupied(items: List<HomeItem>, o: Orient, excludeId: String?): List<Cell> =
        items.asSequence().filter { it.id != excludeId }.mapNotNull { it.cellFor(o) }.toList()

    fun isFree(cell: Cell, items: List<HomeItem>, o: Orient, excludeId: String? = null): Boolean {
        if (!cell.fits(GridSpec.cols(o), GridSpec.rows(o))) return false
        return occupied(items, o, excludeId).none { it.overlaps(cell) }
    }

    /** Closest free position to [desired] for a block of the same size, or null when nothing fits. */
    fun findFreeNear(desired: Cell, items: List<HomeItem>, o: Orient, excludeId: String?): Cell? {
        val cols = GridSpec.cols(o)
        val rows = GridSpec.rows(o)
        val target = desired.clampedTo(cols, rows)
        val taken = occupied(items, o, excludeId)
        var best: Cell? = null
        var bestDist = Int.MAX_VALUE
        for (r in 0..rows - target.h) for (c in 0..cols - target.w) {
            val cand = Cell(c, r, target.w, target.h)
            if (taken.any { it.overlaps(cand) }) continue
            val dc = c - desired.col
            val dr = r - desired.row
            val dist = dc * dc + dr * dr
            if (dist < bestDist) { best = cand; bestDist = dist }
        }
        return best
    }

    /** First free spot (row-major) for a [w] x [h] block, optionally restricted to [region]. */
    fun autoPlace(
        w: Int, h: Int, items: List<HomeItem>, o: Orient,
        region: Cell? = null, excludeId: String? = null,
    ): Cell? {
        val cols = GridSpec.cols(o)
        val rows = GridSpec.rows(o)
        val taken = occupied(items, o, excludeId)
        val c0 = region?.col ?: 0
        val r0 = region?.row ?: 0
        val c1 = minOf(cols, region?.let { it.col + it.w } ?: cols)
        val r1 = minOf(rows, region?.let { it.row + it.h } ?: rows)
        for (r in r0..r1 - h) for (c in c0..c1 - w) {
            val cand = Cell(c, r, w, h)
            if (taken.none { it.overlaps(cand) }) return cand
        }
        return null
    }

    /** Default footprint for items that have not been placed in an orientation yet. */
    fun defaultSize(item: HomeItem, o: Orient): Pair<Int, Int> {
        val other = item.cellFor(if (o == Orient.LAND) Orient.PORT else Orient.LAND)
        val cols = GridSpec.cols(o)
        val rows = GridSpec.rows(o)
        if (other != null) return other.w.coerceIn(1, cols) to other.h.coerceIn(1, rows)
        return when (item.kind) {
            ItemKind.APP -> 1 to 1
            ItemKind.WIDGET -> 3 to 2
            ItemKind.PHOTO -> 3 to 3
            ItemKind.QUOTE -> 3 to 2
            ItemKind.CLOCK -> 4 to 2
        }
    }

    /**
     * Gives every item a position in [o]. Items that already have one are never moved, so this is safe
     * to call on every start-up and after orientation changes.
     */
    fun ensureCells(items: List<HomeItem>, o: Orient): List<HomeItem> {
        if (items.all { it.cellFor(o) != null }) return items
        val result = items.toMutableList()
        for (i in result.indices) {
            val item = result[i]
            if (item.cellFor(o) != null) continue
            val (w, h) = defaultSize(item, o)
            var cell = autoPlace(w, h, result, o)
            // Shrink a block that cannot be placed so nothing silently disappears.
            var ww = w
            var hh = h
            while (cell == null && (ww > 1 || hh > 1)) {
                if (ww >= hh && ww > 1) ww-- else hh--
                cell = autoPlace(ww, hh, result, o)
            }
            result[i] = item.withCell(o, cell)
        }
        return result
    }

    /** Smallest footprint a resize may reach. */
    fun minSpan(item: HomeItem, widgetMin: Pair<Int, Int>? = null): Pair<Int, Int> = when (item.kind) {
        ItemKind.APP -> 1 to 1
        ItemKind.WIDGET -> widgetMin ?: (1 to 1)
        ItemKind.PHOTO -> 1 to 1
        ItemKind.QUOTE -> 2 to 1
        ItemKind.CLOCK -> 2 to 1
    }

    /**
     * Resizing: the free span closest to the requested one (never overlapping another item), or null
     * if not even the minimum span is free.
     */
    fun resolveResize(
        item: HomeItem, o: Orient, items: List<HomeItem>, wantW: Int, wantH: Int,
        minW: Int, minH: Int, limitW: Int = Int.MAX_VALUE, limitH: Int = Int.MAX_VALUE,
    ): Cell? {
        val start = item.cellFor(o) ?: return null
        val maxW = minOf(GridSpec.cols(o) - start.col, limitW)
        val maxH = minOf(GridSpec.rows(o) - start.row, limitH)
        var best: Cell? = null
        var bestDist = Int.MAX_VALUE
        for (w in minW.coerceAtMost(maxW)..maxW) for (h in minH.coerceAtMost(maxH)..maxH) {
            val cand = Cell(start.col, start.row, w, h)
            if (!isFree(cand, items, o, item.id)) continue
            val dist = Math.abs(w - wantW) + Math.abs(h - wantH)
            if (dist < bestDist) { best = cand; bestDist = dist }
        }
        return best
    }
}
