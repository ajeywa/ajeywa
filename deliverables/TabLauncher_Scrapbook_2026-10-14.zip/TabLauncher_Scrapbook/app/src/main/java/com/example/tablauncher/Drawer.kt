package com.example.tablauncher

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitVerticalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.verticalDrag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Pull the drawer down from its handle/search area. Mirror of [swipeUpToOpenDrawer]. */
private fun Modifier.dragDrawerClosed(drawer: DrawerController, travelPx: Float): Modifier = pointerInput(drawer, travelPx) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val tracker = VelocityTracker()
        tracker.addPosition(down.uptimeMillis, down.position)
        val travel = travelPx.coerceAtLeast(1f)
        var startDy = 0f
        var downward = false
        val claimed = awaitVerticalTouchSlopOrCancellation(down.id) { change, over ->
            if (over > 0f) { downward = true; startDy = over; change.consume() }
        }
        if (claimed == null || !downward) return@awaitEachGesture
        drawer.beginDrag()
        drawer.dragBy(-startDy / travel)
        verticalDrag(claimed.id) { change ->
            tracker.addPosition(change.uptimeMillis, change.position)
            drawer.dragBy(-change.positionChange().y / travel)
            change.consume()
        }
        drawer.settle(tracker.calculateVelocity().y, travel)
    }
}

@Composable
fun AppDrawer(env: LauncherEnv, apps: List<AppEntry>, modifier: Modifier = Modifier) {
    val ui = env.ui
    val drawer = ui.drawer
    val palette = LocalPalette.current
    val settings = env.store.state.settings
    var query by remember { mutableStateOf("") }
    val insets = WindowInsets.systemBars.union(WindowInsets.displayCutout)
    val filtered = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
    }

    BoxWithConstraints(
        modifier
            .fillMaxSize()
            .graphicsLayer {
                val p = drawer.progress
                translationY = (1f - p) * size.height
                alpha = (p * 2.2f).coerceIn(0f, 1f)
            }
            // Swallow touches so nothing underneath reacts while the drawer is up.
            .pointerInput(Unit) { detectTapGestures { } }
            .background(
                Brush.verticalGradient(
                    listOf(palette.c0.copy(alpha = 0.94f), palette.c1.copy(alpha = 0.96f), palette.c0.copy(alpha = 0.98f)),
                ),
            ),
    ) {
        val travel = with(LocalDensity.current) { maxHeight.toPx() }
        var gridDrag by remember { mutableStateOf(false) }
        val nested = remember(drawer, travel) {
            object : NestedScrollConnection {
                // Grid is already at its top and the finger keeps moving down: carry the whole drawer down.
                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                    if (source == NestedScrollSource.UserInput && available.y > 0f) {
                        if (!gridDrag) { drawer.beginDrag(); gridDrag = true }
                        drawer.dragBy(-available.y / travel)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }

                // Finger reverses while the drawer is part-way down: lift it back up before scrolling the grid.
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    if (gridDrag && source == NestedScrollSource.UserInput && available.y < 0f && drawer.progress < 1f) {
                        drawer.dragBy(-available.y / travel)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }

                override suspend fun onPreFling(available: Velocity): Velocity {
                    if (!gridDrag) return Velocity.Zero
                    gridDrag = false
                    drawer.settle(available.y, travel)
                    return available
                }
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(insets)
                .imePadding()
                .padding(horizontal = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Handle + search: dragging this area also pulls the drawer down.
            Column(
                Modifier.fillMaxWidth().dragDrawerClosed(drawer, travel),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .padding(top = 10.dp, bottom = 14.dp)
                        .size(width = 54.dp, height = 20.dp)
                        .semantics { contentDescription = "Close app drawer" }
                        .pointerInput(Unit) { detectTapGestures { drawer.close() } },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.size(width = 40.dp, height = 4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.6f)))
                }
                if (ui.pickApp) {
                    Text(
                        "choose an app for your home screen",
                        style = labelStyle(palette.glyph).copy(fontSize = 13.sp),
                        modifier = Modifier.padding(bottom = 10.dp),
                    )
                }
                Frosted(
                    Modifier.widthIn(max = 520.dp).fillMaxWidth().height(50.dp),
                    RoundedCornerShape(25.dp),
                    tint = Color.White.copy(alpha = 0.2f), elevation = 0.dp,
                ) {
                    Row(
                        Modifier.fillMaxSize().padding(horizontal = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(Icons.Rounded.Search, null, tint = palette.glyph.copy(alpha = 0.85f), modifier = Modifier.size(20.dp))
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = palette.glyph, fontSize = 16.sp),
                            cursorBrush = SolidColor(palette.glyph),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                filtered.firstOrNull()?.let { chooseApp(env, it, Rect.Zero) }
                            }),
                            modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Search apps" },
                            decorationBox = { inner ->
                                if (query.isEmpty()) Text("search apps", color = palette.glyph.copy(alpha = 0.65f), fontSize = 16.sp)
                                inner()
                            },
                        )
                    }
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Adaptive(104.dp),
                modifier = Modifier.fillMaxSize().nestedScroll(nested).padding(top = 12.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 40.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(filtered, key = { it.key }) { app -> DrawerCell(env, app, settings) }
            }
        }
    }
}

private fun chooseApp(env: LauncherEnv, app: AppEntry, bounds: Rect) {
    val ui = env.ui
    if (ui.pickApp) {
        if (env.store.isOnHome(app.key)) env.toast("${app.label} is already on Home")
        else if (!env.store.addApp(app.key, ui.orient)) env.toast("No room left on Home. Remove or resize something first.")
        ui.pickApp = false
        ui.drawer.close()
    } else {
        env.repo.launch(app, android.graphics.Rect(bounds.left.toInt(), bounds.top.toInt(), bounds.right.toInt(), bounds.bottom.toInt()))
    }
}

@Composable
private fun DrawerCell(env: LauncherEnv, app: AppEntry, settings: LauncherSettings) {
    val ui = env.ui
    val palette = LocalPalette.current
    var bounds by remember { mutableStateOf(Rect.Zero) }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .onGloballyPositioned { bounds = it.boundsInRoot() }
            .semantics { contentDescription = app.label }
            .pointerInput(app.key) {
                detectTapGestures(
                    onTap = { chooseApp(env, app, bounds) },
                    onLongPress = {
                        ui.lastLongPressMs = System.currentTimeMillis()
                        ui.menu = MenuRequest(MenuKind.APP_DRAWER, bounds, app = app)
                    },
                )
            }
            .padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AppGlyph(app, settings.iconStyle, palette.glyph, 56.dp)
        Text(
            app.label,
            style = labelStyle(palette.glyph).copy(fontSize = 12.sp, lineHeight = 14.sp),
            maxLines = 2,
            overflow = LabelOverflow,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, start = 4.dp, end = 4.dp),
        )
    }
}
