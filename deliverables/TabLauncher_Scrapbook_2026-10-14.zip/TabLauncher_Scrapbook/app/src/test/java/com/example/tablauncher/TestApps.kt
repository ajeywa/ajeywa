package com.example.tablauncher

import android.content.ComponentName
import android.graphics.Color
import android.graphics.Path
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import android.graphics.drawable.shapes.PathShape
import android.graphics.drawable.shapes.RectShape
import android.graphics.drawable.shapes.RoundRectShape
import android.os.Process

/**
 * Placeholder apps for JVM tests. The icons are simple adaptive icons whose foreground is a glyph
 * with transparency around it, like real icons, so the launcher's glyph renderer has something real
 * to chew on. They are NOT real app icons.
 */
object TestApps {
    private fun glyph(kind: Int): Drawable {
        val shape = ShapeDrawable(
            when (kind % 6) {
                0 -> OvalShape()
                1 -> RoundRectShape(FloatArray(8) { 18f }, null, null)
                2 -> PathShape(Path().apply { moveTo(50f, 4f); lineTo(96f, 92f); lineTo(4f, 92f); close() }, 100f, 100f)
                3 -> PathShape(Path().apply { moveTo(50f, 2f); lineTo(98f, 50f); lineTo(50f, 98f); lineTo(2f, 50f); close() }, 100f, 100f)
                4 -> RectShape()
                else -> PathShape(
                    Path().apply { addCircle(50f, 50f, 46f, Path.Direction.CW); addCircle(50f, 50f, 22f, Path.Direction.CCW) },
                    100f, 100f,
                )
            },
        )
        shape.paint.color = Color.WHITE
        return InsetDrawable(shape, 0.30f)
    }

    private fun icon(kind: Int): Drawable =
        AdaptiveIconDrawable(ColorDrawable(Color.rgb(60 + kind * 12 % 160, 90, 150)), glyph(kind))

    private val names = listOf(
        "Chrome", "Gallery", "Camera", "Messages", "Settings", "Calendar", "Music", "Maps",
        "Mail", "Notes", "Phone", "Files", "Clock", "Weather", "Wallet", "Podcasts",
    )

    fun build(count: Int = names.size): List<AppEntry> = names.take(count).mapIndexed { i, label ->
        val pkg = "com.test.${label.lowercase()}"
        val cn = ComponentName(pkg, "$pkg.Main")
        AppEntry(
            key = AppRepository.keyOf(cn, 0L),
            label = label,
            component = cn,
            user = Process.myUserHandle(),
            isPrimaryUser = true,
            // Settings behaves like a pure system app: it must not offer Uninstall.
            pureSystem = label == "Settings" || label == "Phone",
            icon = icon(i),
        )
    }
}
