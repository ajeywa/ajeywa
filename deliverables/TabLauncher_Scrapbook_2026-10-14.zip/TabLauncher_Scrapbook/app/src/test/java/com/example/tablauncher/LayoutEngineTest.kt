package com.example.tablauncher

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/** Pure grid maths and (de)serialisation. Robolectric is only here because org.json is an Android class. */
@RunWith(RobolectricTestRunner::class)
class LayoutEngineTest {
    private fun app(id: String, c: Cell?) = HomeItem(id, ItemKind.APP, appKey = id, land = c)
    private fun widget(id: String, c: Cell?) = HomeItem(id, ItemKind.WIDGET, widgetId = id.hashCode(), land = c)

    @Test fun cellsOverlapOnlyWhenTheyShareArea() {
        assertTrue(Cell(0, 0, 2, 2).overlaps(Cell(1, 1, 2, 2)))
        assertFalse(Cell(0, 0, 2, 2).overlaps(Cell(2, 0, 2, 2)))
        assertFalse(Cell(0, 0, 1, 1).overlaps(Cell(0, 1, 1, 1)))
    }

    @Test fun freeSpotNeverOverlapsAndStaysInGrid() {
        val items = listOf(widget("w", Cell(2, 2, 4, 2)))
        val spot = LayoutEngine.findFreeNear(Cell(3, 2, 1, 1), items, Orient.LAND, null)!!
        assertTrue(spot.fits(GridSpec.LAND_COLS, GridSpec.LAND_ROWS))
        assertFalse(spot.overlaps(Cell(2, 2, 4, 2)))
        // Nearest free cell to the middle of the blocked area is directly above or below it.
        assertTrue(spot.row == 1 || spot.row == 4)
    }

    @Test fun draggingOntoItselfIsAllowedBecauseItIsExcluded() {
        val items = listOf(app("a", Cell(5, 3, 1, 1)))
        assertEquals(Cell(5, 3, 1, 1), LayoutEngine.findFreeNear(Cell(5, 3, 1, 1), items, Orient.LAND, "a"))
    }

    @Test fun findFreeNearReturnsNullWhenGridIsFull() {
        val full = listOf(widget("all", Cell(0, 0, GridSpec.LAND_COLS, GridSpec.LAND_ROWS)))
        assertNull(LayoutEngine.findFreeNear(Cell(0, 0, 1, 1), full, Orient.LAND, null))
        assertNull(LayoutEngine.autoPlace(1, 1, full, Orient.LAND))
    }

    @Test fun autoPlaceRespectsRegion() {
        val spot = LayoutEngine.autoPlace(2, 1, emptyList(), Orient.LAND, Cell(6, 3, 4, 2))!!
        assertEquals(Cell(6, 3, 2, 1), spot)
    }

    @Test fun ensureCellsNeverMovesPlacedItemsAndGivesOthersAFreeSpot() {
        val placed = app("a", Cell(0, 0, 1, 1)).copy(port = Cell(0, 0, 1, 1))
        val unplaced = HomeItem("b", ItemKind.PHOTO, land = Cell(0, 1, 3, 3)) // no portrait cell yet
        val out = LayoutEngine.ensureCells(listOf(placed, unplaced), Orient.PORT)
        assertEquals(Cell(0, 0, 1, 1), out[0].port)
        val cell = out[1].port!!
        assertEquals(3, cell.w); assertEquals(3, cell.h)
        assertFalse(cell.overlaps(out[0].port!!))
        assertTrue(cell.fits(GridSpec.PORT_COLS, GridSpec.PORT_ROWS))
    }

    @Test fun ensureCellsShrinksInsteadOfDroppingAnItem() {
        val blocker = widget("blocker", Cell(0, 0, GridSpec.PORT_COLS, GridSpec.PORT_ROWS - 1)).copy(port = Cell(0, 0, GridSpec.PORT_COLS, GridSpec.PORT_ROWS - 1))
        val big = HomeItem("big", ItemKind.PHOTO, land = Cell(0, 0, 5, 5))
        val out = LayoutEngine.ensureCells(listOf(blocker, big), Orient.PORT)
        val placed = out[1].port
        assertNotNull(placed)
        assertEquals(1, placed!!.h) // only one free row left
    }

    @Test fun resizeFindsClosestFreeSpanAndNeverOverlaps() {
        val w = widget("w", Cell(0, 0, 2, 2))
        val neighbour = app("n", Cell(4, 0, 1, 1))
        val items = listOf(w, neighbour)
        // Asking for 6 wide would hit the neighbour at column 4, so it stops at 4 wide.
        val r = LayoutEngine.resolveResize(w, Orient.LAND, items, wantW = 6, wantH = 2, minW = 1, minH = 1)!!
        assertEquals(Cell(0, 0, 4, 2).w, r.w)
        assertFalse(r.overlaps(neighbour.land!!))
    }

    @Test fun resizeRespectsMinimumAndLimits() {
        val w = widget("w", Cell(0, 0, 3, 3))
        val r = LayoutEngine.resolveResize(w, Orient.LAND, listOf(w), wantW = 1, wantH = 1, minW = 2, minH = 2)!!
        assertEquals(2, r.w); assertEquals(2, r.h)
        val locked = LayoutEngine.resolveResize(w, Orient.LAND, listOf(w), wantW = 8, wantH = 3, minW = 1, minH = 3, limitH = 3)!!
        assertEquals(3, locked.h)
    }

    @Test fun stateRoundTripsThroughJson() {
        val state = LauncherState(
            items = listOf(
                app("a", Cell(1, 2, 1, 1)).copy(port = Cell(3, 4, 1, 1)),
                widget("w", Cell(0, 0, 4, 2)),
                HomeItem("p", ItemKind.PHOTO, photo = "x.jpg", style = 2, tilt = -3f, land = Cell(0, 4, 2, 2)),
                HomeItem("q", ItemKind.QUOTE, text = "take it slow.", style = 1, land = Cell(9, 0, 3, 2)),
            ),
            dock = listOf("k1", "k2"),
            settings = LauncherSettings(palette = 2, wallpaper = WallpaperMode.PHOTO, wallpaperPhoto = "bg.jpg", iconStyle = IconStyle.ORIGINAL, showLabels = false),
        )
        val back = LauncherState.fromJson(JSONObject(state.toJson().toString()))
        assertEquals(state, back)
    }

    @Test fun corruptJsonItemsAreSkippedNotFatal() {
        val json = JSONObject("""{"items":[{"id":"a","kind":"NOPE"},{"kind":"APP"},{"id":"ok","kind":"CLOCK"}],"dock":["x",""]}""")
        val s = LauncherState.fromJson(json)
        assertEquals(listOf("ok"), s.items.map { it.id })
        assertEquals(listOf("x"), s.dock)
    }

    @Test fun defaultCompositionIsAsymmetricNonOverlappingAndKeepsWidgetIds() {
        val widgets = listOf(
            HomeItem("w1", ItemKind.WIDGET, widgetId = 41, land = Cell(0, 0, 4, 2)),
            HomeItem("w2", ItemKind.WIDGET, widgetId = 42, land = Cell(0, 0, 3, 2), port = Cell(0, 0, 3, 2)),
        )
        val s = DefaultLayout.build(List(7) { "app$it" }, listOf("d1", "d2", "d3"), widgets)
        assertEquals(setOf(41, 42), s.items.filter { it.kind == ItemKind.WIDGET }.map { it.widgetId }.toSet())
        for (o in Orient.values()) {
            val cells = s.items.mapNotNull { it.cellFor(o) }
            cells.forEach { assertTrue("$it out of grid in $o", it.fits(GridSpec.cols(o), GridSpec.rows(o))) }
            for (i in cells.indices) for (j in i + 1 until cells.size) {
                assertFalse("${cells[i]} overlaps ${cells[j]} in $o", cells[i].overlaps(cells[j]))
            }
        }
        assertEquals(listOf("d1", "d2", "d3"), s.dock)
        // Not a uniform grid: more than one distinct item footprint on screen.
        assertTrue(s.items.mapNotNull { it.land }.map { it.w to it.h }.toSet().size >= 4)
    }
}
