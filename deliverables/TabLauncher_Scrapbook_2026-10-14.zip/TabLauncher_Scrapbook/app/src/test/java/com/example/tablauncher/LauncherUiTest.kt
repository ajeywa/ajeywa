package com.example.tablauncher

import android.app.Application
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.longClick
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.compose.ui.test.center
import androidx.compose.ui.test.down
import androidx.compose.ui.test.moveBy
import androidx.compose.ui.test.up
import androidx.compose.ui.test.click
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

/**
 * Drives the real MainActivity on the JVM with Robolectric, on a 1280 x 800 dp landscape tablet.
 * This verifies the launcher's own logic and gestures. It does not verify OEM behaviour
 * (Samsung's widget picker, gesture-navigation edge cases, real RenderEffect blur): see the README.
 */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w1280dp-h800dp-land-xhdpi")
class LauncherUiTest {
    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    private val apps = TestApps.build()
    private val launched = mutableListOf<String>()
    private val env get() = rule.activity.env!!
    private val store get() = env.store
    private val ui get() = env.ui

    private fun boot() {
        // The fake apps must look installed, otherwise the launcher (correctly) prunes them from the layout.
        val pm = shadowOf(rule.activity.packageManager)
        apps.forEach { pm.addActivityIfNotPresent(it.component) }
        // Respect "remove animations": the endless edit-mode jiggle would otherwise keep Compose tests busy.
        android.provider.Settings.Global.putFloat(rule.activity.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 0f)
        rule.activity.repo.launchInterceptor = { launched += it.label; true }
        rule.activity.appsOverride = apps
        rule.waitForIdle()
    }

    private fun key(label: String) = apps.first { it.label == label }.key
    private fun homeApp(label: String) = store.state.items.firstOrNull { it.kind == ItemKind.APP && it.appKey == key(label) }

    /**
     * Screenshots: Compose's captureToImage() relies on PixelCopy, which times out under Robolectric, so the
     * window is drawn into a bitmap directly. Backdrop blur (RenderEffect) is not rendered this way.
     */
    private fun shot(name: String) {
        val dir = File(System.getProperty("shotDir") ?: "build/screenshots").apply { mkdirs() }
        // Icons are rendered on a background dispatcher that Compose's idling check doesn't know about.
        repeat(6) { Thread.sleep(300); rule.waitForIdle() }
        val view = rule.activity.window.decorView
        val bmp = android.graphics.Bitmap.createBitmap(view.width, view.height, android.graphics.Bitmap.Config.ARGB_8888)
        rule.runOnUiThread { view.draw(android.graphics.Canvas(bmp)) }
        File(dir, "$name.png").outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
    }

    // ---- first run ---------------------------------------------------------------------------

    @Test fun firstRunSeedsAScrapbookHomeWithDockAndDecor() {
        boot()
        val kinds = store.state.items.map { it.kind }.toSet()
        assertTrue(ItemKind.CLOCK in kinds && ItemKind.QUOTE in kinds && ItemKind.PHOTO in kinds && ItemKind.APP in kinds)
        assertTrue("dock should be populated", store.state.dock.size in 1..GridSpec.LAND_COLS)
        rule.onNodeWithText("take it slow.").assertExists()
        shot("01_home")
    }

    // ---- long-press ---------------------------------------------------------------------------

    @Test fun longPressShowsMenuWithoutRemovingOrLaunching() {
        boot()
        val before = store.state.items
        assertNotNull(homeApp("Calendar"))
        rule.onNodeWithContentDescription("Calendar").performTouchInput { longClick() }
        rule.waitForIdle()

        rule.onNodeWithText("App info").assertExists()
        rule.onNodeWithText("Uninstall").assertExists()
        rule.onNodeWithText("Remove from Home").assertExists()
        shot("02_longpress_menu")

        // Nothing was removed and nothing was launched by the long-press itself.
        assertEquals(before, store.state.items)
        assertTrue("long-press must not launch the app: $launched", launched.isEmpty())
        assertNotNull(homeApp("Calendar"))
    }

    @Test fun menuDismissesOnOutsideTapAndBack() {
        boot()
        rule.onNodeWithContentDescription("Calendar").performTouchInput { longClick() }
        rule.waitForIdle()
        rule.onNodeWithText("App info").assertExists()
        rule.runOnUiThread { rule.activity.onBackPressedDispatcher.onBackPressed() }
        rule.waitForIdle()
        rule.onNodeWithText("App info").assertDoesNotExist()
        assertNotNull(homeApp("Calendar"))
    }

    @Test fun uninstallOpensTheSystemConfirmationAndNeverUninstallsSilently() {
        boot()
        rule.onNodeWithContentDescription("Calendar").performTouchInput { longClick() }
        rule.waitForIdle()
        rule.onNodeWithText("Uninstall").performClick()
        rule.waitForIdle()
        val started = shadowOf(rule.activity).nextStartedActivity
        assertNotNull("Uninstall must hand over to the system", started)
        assertEquals(Intent.ACTION_DELETE, started.action)
        assertEquals("package:com.test.calendar", started.data.toString())
        // The launcher itself did not touch the layout: the system dialog decides.
        assertNotNull(homeApp("Calendar"))
    }

    @Test fun pureSystemAppsDoNotOfferUninstall() {
        boot()
        rule.onNodeWithContentDescription("Settings").performTouchInput { longClick() }
        rule.waitForIdle()
        rule.onNodeWithText("App info").assertExists()
        rule.onNodeWithText("Uninstall").assertDoesNotExist()
    }

    @Test fun removeFromHomeIsAnExplicitMenuChoiceOnly() {
        boot()
        rule.onNodeWithContentDescription("Calendar").performTouchInput { longClick() }
        rule.waitForIdle()
        rule.onNodeWithText("Remove from Home").performClick()
        rule.waitForIdle()
        assertNull(homeApp("Calendar"))
        assertTrue("the app itself must still be listed", apps.any { it.label == "Calendar" })
    }

    @Test fun tapLaunchesTheApp() {
        boot()
        rule.onNodeWithContentDescription("Calendar").performClick()
        rule.waitForIdle()
        assertEquals(listOf("Calendar"), launched)
    }

    // ---- swipe-up drawer -----------------------------------------------------------------------

    @Test fun swipeUpFromTheDockZoneOpensTheDrawerAndItListsEveryApp() {
        boot()
        rule.onRoot().performTouchInput {
            swipe(Offset(width / 2f, height - 90f), Offset(width / 2f, height * 0.25f), durationMillis = 260)
        }
        rule.waitForIdle()
        assertEquals(1f, ui.drawer.progress, 0.001f)
        rule.onNodeWithContentDescription("Search apps").assertExists()
        shot("03_drawer")
        // Every launchable app is reachable in the drawer (the grid is scrollable; all 16 fit on this screen).
        for (a in apps) assertTrue("${a.label} missing in drawer", rule.onAllNodesWithContentDescription(a.label).fetchSemanticsNodes().isNotEmpty())

        // The home icon sits underneath the drawer; the drawer's own cell is the last match.
        val music = rule.onAllNodesWithContentDescription("Music")
        music[music.fetchSemanticsNodes().size - 1].performClick()
        rule.waitForIdle()
        assertEquals(listOf("Music"), launched)
    }

    @Test fun swipeUpOnEmptyWallpaperAlsoOpensTheDrawer() {
        boot()
        // Empty region between the clock band and the bottom apps of the seeded layout.
        rule.onRoot().performTouchInput { swipe(Offset(width * 0.93f, height * 0.62f), Offset(width * 0.93f, height * 0.15f), durationMillis = 260) }
        rule.waitForIdle()
        assertEquals(1f, ui.drawer.progress, 0.001f)
    }

    @Test fun shortUpwardDragThatIsNotAFlingSnapsBackClosed() {
        boot()
        rule.onRoot().performTouchInput { swipe(Offset(width / 2f, height - 90f), Offset(width / 2f, height - 150f), durationMillis = 900) }
        rule.waitForIdle()
        assertEquals(0f, ui.drawer.progress, 0.001f)
    }

    @Test fun swipeDownClosesTheDrawer() {
        boot()
        ui.drawer.open()
        rule.waitForIdle()
        assertEquals(1f, ui.drawer.progress, 0.001f)
        rule.onRoot().performTouchInput { swipe(Offset(width / 2f, height * 0.45f), Offset(width / 2f, height * 0.95f), durationMillis = 260) }
        rule.waitForIdle()
        assertEquals(0f, ui.drawer.progress, 0.001f)
        rule.onNodeWithContentDescription("Search apps").assertDoesNotExist()
    }

    @Test fun backAndHomeButtonCloseTheDrawer() {
        boot()
        ui.drawer.open(); rule.waitForIdle()
        rule.runOnUiThread { rule.activity.onBackPressedDispatcher.onBackPressed() }
        rule.waitForIdle()
        assertEquals(0f, ui.drawer.progress, 0.001f)

        ui.drawer.open(); rule.waitForIdle()
        rule.runOnUiThread { rule.activity.onNewIntent(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) }
        rule.waitForIdle()
        assertEquals(0f, ui.drawer.progress, 0.001f)
    }

    @Test fun tapOnTheHandleOpensDrawerForPeopleWhoCannotSwipe() {
        boot()
        rule.onNodeWithContentDescription("Open app drawer").performClick()
        rule.waitForIdle()
        assertEquals(1f, ui.drawer.progress, 0.001f)
    }

    @Test fun drawerSearchFiltersApps() {
        boot()
        ui.drawer.open(); rule.waitForIdle()
        rule.onNodeWithContentDescription("Search apps").performTextInput("wal")
        rule.waitForIdle()
        // "Wallet" and "Podcasts" exist only in the drawer, so they show the filter at work.
        assertEquals(1, rule.onAllNodesWithContentDescription("Wallet").fetchSemanticsNodes().size)
        rule.onNodeWithContentDescription("Podcasts").assertDoesNotExist()
    }

    // ---- arranging -----------------------------------------------------------------------------

    @Test fun longPressOnEmptyWallpaperEntersArrangeModeAndDoneLeavesIt() {
        boot()
        rule.onRoot().performTouchInput { longClick(Offset(width * 0.93f, height * 0.62f)) }
        rule.waitForIdle()
        assertTrue(ui.editing)
        rule.onNodeWithText("Done").assertExists()
        shot("04_edit_mode")
        rule.onNodeWithText("Done").performClick()
        rule.waitForIdle()
        assertFalse(ui.editing)
    }

    @Test fun draggingAnIconInArrangeModeMovesItToAFreeCellAndPersists() {
        boot()
        ui.editing = true; rule.waitForIdle()
        val before = homeApp("Calendar")!!.land!!
        val dxCells = 2
        val dx = ui.cellWpx * dxCells
        rule.onNodeWithContentDescription("Calendar").performTouchInput {
            swipe(center, center + Offset(dx, 0f), durationMillis = 300)
        }
        rule.waitForIdle()
        val after = homeApp("Calendar")!!.land!!
        assertTrue("icon should have moved right: $before -> $after", after.col > before.col || after != before)
        val others = store.state.items.filter { it.appKey != key("Calendar") }.mapNotNull { it.land }
        assertTrue(others.none { it.overlaps(after) })
        // Persisted: a fresh store reading the same preferences sees the same position.
        val fresh = LauncherStore(rule.activity)
        assertEquals(after, fresh.state.items.first { it.appKey == key("Calendar") }.land)
    }

    @Test fun draggingAfterLongPressCarriesTheIconInsteadOfLeavingTheMenuOpen() {
        boot()
        val before = homeApp("Calendar")!!.land!!
        rule.onNodeWithContentDescription("Calendar").performTouchInput {
            down(center)
            advanceEventTime(700)
            moveBy(Offset(ui.cellWpx * 2f, 0f), delayMillis = 300)
            up()
        }
        rule.waitForIdle()
        rule.onNodeWithText("App info").assertDoesNotExist()
        assertNotNull(homeApp("Calendar"))
        assertTrue(launched.isEmpty())
        assertTrue(homeApp("Calendar")!!.land!!.let { it != before })
    }

    @Test fun resizeHandleGrowsAPhotoTileWithoutOverlap() {
        boot()
        ui.editing = true; rule.waitForIdle()
        val photo = store.state.items.first { it.kind == ItemKind.PHOTO && it.style == 2 }
        val before = photo.land!!
        val handles = rule.onAllNodesWithContentDescription("Resize")
        val count = handles.fetchSemanticsNodes().size
        assertTrue("resize handles shown for resizable items", count >= 3)
        // The handle of the polaroid is the one at the lowest row: find it by position.
        val nodes = handles.fetchSemanticsNodes()
        val idx = nodes.indices.maxByOrNull { nodes[it].boundsInRoot.top }!!
        handles[idx].performTouchInput { swipe(center, center + Offset(ui.cellWpx * 1.2f, 0f), durationMillis = 300) }
        rule.waitForIdle()
        val after = store.state.items.first { it.id == photo.id }.land!!
        assertTrue("tile should be wider: $before -> $after", after.w > before.w)
        assertTrue(store.state.items.filter { it.id != photo.id }.mapNotNull { it.land }.none { it.overlaps(after) })
    }

    @Test fun addingNotesPhotosAndClocksFromTheEditBar() {
        boot()
        ui.editing = true; rule.waitForIdle()
        val before = store.state.items.size
        rule.onNodeWithText("Clock").performClick(); rule.waitForIdle()
        assertEquals(before + 1, store.state.items.size)
        rule.onNodeWithText("Note").performClick(); rule.waitForIdle()
        assertEquals(before + 2, store.state.items.size)
        assertEquals(SheetKind.NOTE, ui.sheet)
        shot("05_note_sheet")
    }

    @Test fun styleSheetChangesPalettePersistsAndIsReadBackOnRestart() {
        boot()
        ui.editing = true; rule.waitForIdle()
        rule.onNodeWithText("Style").performClick(); rule.waitForIdle()
        rule.onNodeWithText("sage").performClick(); rule.waitForIdle()
        assertEquals(1, store.state.settings.palette)
        shot("06_style_sheet")
        assertEquals(1, LauncherStore(rule.activity).state.settings.palette)
    }

    @Test fun usingPickModePlacesAnAppOnHome() {
        boot()
        rule.runOnUiThread { store.removeItem(homeApp("Calendar")!!.id) }
        rule.waitForIdle()
        assertNull(homeApp("Calendar"))
        ui.pickApp = true
        ui.drawer.open(); rule.waitForIdle()
        rule.onAllNodesWithContentDescription("Calendar")[0].performClick()
        rule.waitForIdle()
        assertNotNull(homeApp("Calendar"))
        assertTrue("picking must not launch", launched.isEmpty())
    }

    // ---- dock ----------------------------------------------------------------------------------

    @Test fun dockLongPressOffersRemoveFromDockNotRemovalFromHome() {
        boot()
        val dockKey = store.state.dock.first()
        val label = apps.first { it.key == dockKey }.label
        val homeBefore = store.state.items
        rule.onNodeWithContentDescription(label).performTouchInput { longClick() }
        rule.waitForIdle()
        rule.onNodeWithText("Remove from Dock").assertExists()
        assertEquals(homeBefore, store.state.items)
        assertTrue(store.state.dock.contains(dockKey))
        assertTrue(launched.isEmpty())
    }

    // ---- persistence & migration --------------------------------------------------------------

    @Test fun legacyPreferencesAreMigratedAndWidgetIdsPreserved() {
        val prefs = ApplicationProvider.getApplicationContext<Application>().getSharedPreferences("launcher", Context.MODE_PRIVATE)
        prefs.edit()
            .putStringSet("widget_ids", setOf("7", "9"))
            .putStringSet("favorites", setOf("com.test.mail", "com.test.notes", "com.test.maps"))
            .putBoolean("favorites_customized", true)
            .commit()
        boot()
        val widgetIds = store.state.items.filter { it.kind == ItemKind.WIDGET }.map { it.widgetId }.sorted()
        assertEquals(listOf(7, 9), widgetIds)
        // Old favourites survive, either on Home or in the dock.
        val kept = (store.state.dock + store.state.items.mapNotNull { it.appKey }).toSet()
        for (pkg in listOf("mail", "notes", "maps")) assertTrue("$pkg lost in migration", kept.contains(key(pkg.replaceFirstChar { it.uppercase() })))
        // The legacy key is still valid for a downgrade.
        assertEquals(setOf("7", "9"), prefs.getStringSet("widget_ids", emptySet()))
    }

    // ---- native widgets --------------------------------------------------------------------------

    private fun registerProvider(): AppWidgetProviderInfo {
        val shadow = shadowOf(AppWidgetManager.getInstance(rule.activity))
        val pi = android.content.pm.PackageInfo().apply {
            packageName = "com.test.weather"
            applicationInfo = android.content.pm.ApplicationInfo().apply { packageName = "com.test.weather"; name = "Weather"; nonLocalizedLabel = "Weather" }
        }
        shadowOf(rule.activity.packageManager).installPackage(pi)
        val info = AppWidgetProviderInfo().apply {
            // `providerInfo` is a hidden framework field; real providers get it from the system.
            val ai = android.content.pm.ActivityInfo().apply {
                packageName = "com.test.weather"; name = "com.test.weather.Widget"
                applicationInfo = pi.applicationInfo; nonLocalizedLabel = "Weather"
            }
            AppWidgetProviderInfo::class.java.getDeclaredField("providerInfo").apply { isAccessible = true }.set(this, ai)
            provider = ComponentName("com.test.weather", "com.test.weather.Widget")
            minWidth = 250 * 2; minHeight = 110 * 2 // px at xhdpi => 250 x 110 dp
            minResizeWidth = 110 * 2; minResizeHeight = 110 * 2
            resizeMode = AppWidgetProviderInfo.RESIZE_HORIZONTAL or AppWidgetProviderInfo.RESIZE_VERTICAL
            label = "Weather"
            initialLayout = 0
        }
        shadow.addInstalledProvider(info)
        return info
    }

    @Test fun widgetIsBoundPlacedAndRemovedThroughTheRealAppWidgetHost() {
        boot()
        val shadow = shadowOf(AppWidgetManager.getInstance(rule.activity))
        shadow.setAllowedToBindAppWidgets(true)
        registerProvider()
        val controller = env.widgets!!
        val choice = controller.loadChoices().first { it.label == "Weather" }
        // 250x110dp at 86dp/cell => 3 x 2 cells.
        assertEquals(3 to 2, choice.spanW to choice.spanH)
        rule.runOnUiThread { controller.add(choice) }
        rule.waitForIdle()
        val item = store.state.items.single { it.kind == ItemKind.WIDGET }
        assertTrue(item.widgetId != -1)
        assertNotNull(item.land);
        // The host id is the one the previous version used, so existing widgets stay bound after an update.
        assertEquals(2048, WidgetController.HOST_ID)
        shot("07_with_widget")
        rule.runOnUiThread { controller.remove(item) }
        rule.waitForIdle()
        assertTrue(store.state.items.none { it.kind == ItemKind.WIDGET })
    }

    @Test fun withoutBindPermissionTheUserIsSentToTheSystemApprovalScreen() {
        boot()
        val shadow = shadowOf(AppWidgetManager.getInstance(rule.activity))
        shadow.setAllowedToBindAppWidgets(false)
        registerProvider()
        val choice = env.widgets!!.loadChoices().first { it.label == "Weather" }
        rule.runOnUiThread { env.widgets!!.add(choice) }
        rule.waitForIdle()
        val intent = shadowOf(rule.activity).nextStartedActivityForResult.intent
        assertEquals(AppWidgetManager.ACTION_APPWIDGET_BIND, intent.action)
        assertEquals(choice.info.provider, intent.getParcelableExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, ComponentName::class.java))
        assertTrue("nothing is placed until Android grants the bind", store.state.items.none { it.kind == ItemKind.WIDGET })
    }

    // ---- misc --------------------------------------------------------------------------------------

    @Test fun portraitGetsItsOwnNonOverlappingArrangement() {
        boot()
        rule.runOnUiThread { store.ensureCells(Orient.PORT) }
        for (o in Orient.values()) {
            val cells = store.state.items.mapNotNull { it.cellFor(o) }
            assertEquals("every item placed in $o", store.state.items.size, cells.size)
            for (i in cells.indices) for (j in i + 1 until cells.size) assertFalse(cells[i].overlaps(cells[j]))
        }
    }
}
