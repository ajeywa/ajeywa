# Tab Launcher (scrapbook home screen)

A custom Android tablet launcher in Kotlin + Jetpack Compose, redesigned as an asymmetrical, wallpaper-first
"aesthetic iPad" home screen. Same application ID (`com.example.tablauncher`) as before, so installing over
your current build keeps your preferences, widget IDs and default-home choice.

## Open, build, install
1. Android Studio -> **File > Open** -> the folder containing `settings.gradle.kts` (this folder). Trust the project.
2. Let Gradle sync. Needs Android SDK Platform 35 and a JDK 17+ (Android Studio's bundled JDK is fine).
   A Gradle wrapper (8.9, compatible with the unchanged AGP 8.7.3) is included.
3. Tablet: enable USB debugging, select it, press **Run**. Or from a terminal:
   `./gradlew assembleDebug` then `adb install -r app/build/outputs/apk/debug/app-debug.apk`
4. Press Home and choose **Tab Launcher > Always** (or in the launcher: Style > "Make this my home app").
   Don't uninstall the old build or clear its data.

Tests (JVM, no device needed): `./gradlew testDebugUnitTest`.
Versions are unchanged: AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01. Only test dependencies were added.

## What you get
- **Wallpaper first.** Own generated backdrop (4 palettes: Dusk, Sage, Lavender, Midnight), your system wallpaper,
  or a photo you pick. No header, cards or bottom tabs.
- **Freeform collage canvas.** Items sit on a fixed grid per orientation (12x6 landscape, 7x10 portrait), each
  orientation keeps its own arrangement. Item types: native widgets, app icons, photo tiles (rounded / arch /
  polaroid, with built-in paper-cut artwork until you add a photo), a cream note tile, a bare editorial clock.
- **Glyph icons, no containers.** Icons are drawn as single-colour silhouettes (themed monochrome layer on
  Android 13+) with a soft shadow. Icons that can't be reduced to a silhouette fall back to a muted original.
  "Original colours" is a one-tap alternative.
- **Floating frosted dock** (up to 7 apps). Blur behind glass needs the launcher's own backdrop or a photo and
  Android 12+; with the system wallpaper it stays plain translucent glass.
- **Swipe-up drawer.** Swipe up from the dock area or from empty/non-interactive space; it follows your finger and
  settles with velocity. Pull down (from its handle, or from the top of the grid), press Back or Home to close.
  Search field, all launchable apps (including work profile), tap to launch. The small handle above the dock is
  also a tap target for people who can't swipe.
- **Long-press menu, never removal.** App info, Uninstall (opens the system confirmation, hidden for pure system
  apps and when restricted), app shortcuts (only when Tab Launcher is the default home, as Android requires),
  Edit Home, Add/Remove Dock, and an explicit "Remove from Home". Long-press and drag moves the icon instead.
- **Arrange mode** (long-press empty space, or menu > Edit Home): drag items, resize handle, remove badges, add
  Widget / Photo / Art / Note / Clock / App, Style sheet. Dock icons reorder by dragging.
- **Native widgets** via a real `AppWidgetHost` (id 2048, unchanged): in-app widget picker with previews, system
  bind-approval flow when Android requires it, configuration activities, resize (respecting each widget's
  resize mode and minimum), move, remove (releases the widget id), size hints sent to the widget. No card behind
  widgets; the wallpaper shows around them. Existing widget ids are migrated.
- **Persistence.** Layout and style are saved as JSON in the same `launcher` preferences. On first run the old
  `widget_ids` and `favorites` are migrated; `widget_ids` is kept in sync so a downgrade still finds widgets.
- Respects system "remove animations". Home/Back close overlays; Back on Home does nothing, as on any launcher.

## Verification: what was and wasn't tested
**Verified in this environment**
- `./gradlew clean assembleDebug` succeeds (Gradle 8.9 wrapper, JDK 21, Android SDK 35). APK manifest checked:
  application ID, LAUNCHER and HOME/DEFAULT filters intact.
- 38 JVM tests pass (`testDebugUnitTest`): grid/placement/resize logic, JSON round-trip and corrupt-data
  tolerance, default layout, and 26 UI tests that drive the real `MainActivity` under Robolectric on a simulated
  1280x800dp landscape tablet: first-run seeding, legacy-preference migration, tap launches, long-press opens the
  menu without removing or launching, uninstall hands off to `ACTION_DELETE package:...`, pure system apps get no
  Uninstall, swipe-up from the dock and from empty wallpaper opens the drawer, short drags snap back, swipe-down /
  Back / Home close it, search, arrange-mode drag and resize with persistence, adding notes/clocks, style
  persistence, widget bind/place/remove against Robolectric's AppWidget shadows, the bind-approval intent, and a
  separate portrait arrangement.
- Screenshots in `docs/screenshots/` are real renders of the Compose UI from those tests (placeholder
  geometric icons, not real app icons; blur is not rendered by this method).
- The tests found and fixed real defects: a Kotlin 2.0.21 `return@key` miscompile, a swipe band that swallowed
  touches on the bottom icon row, a gesture detector that ignored consumed taps, and merged accessibility nodes.

**Not tested (no emulator/device was available; no KVM in the build sandbox)**
- Behaviour on a real Galaxy Tab S10 Lite: One UI quirks, system gesture navigation edge cases, real RenderEffect
  blur, performance, the real widget picker data, third-party widgets and their configuration screens, work-profile
  apps, app shortcuts, the system uninstall dialog, and the photo picker. Please try these and report anything odd.
- Colour/taste judgement against your references was done on the Robolectric render only.

## Known limitations
- Third-party widgets draw their own insides; the launcher controls position, size, clipping and surroundings.
- One home page; no folders, no drag from the drawer onto Home (use the long-press menu "Add to Home" or
  Arrange > App), no drag between Home and Dock (menu instead).
- Portrait and landscape arrangements are separate; items new to an orientation are auto-placed first-fit.
- `updateAppWidgetSize(Bundle,...)` is deprecated but still the call that works on API 26-34.
